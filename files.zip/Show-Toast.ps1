#Requires -Version 5.1

<#
.SYNOPSIS
    Displays a Windows toast notification to the current user.

.DESCRIPTION
    Uses the Windows Runtime (WinRT) toast notification API to display
    a toast notification. Must be run in the user session context.
    Called from Install-TSScanServer.ps1 via ServiceUI_x64.exe.

.PARAMETER Title
    The title text of the toast notification.

.PARAMETER Message
    The body text of the toast notification.

.EXAMPLE
    powershell.exe -File ".\Show-Toast.ps1" -Title "TSScan Server" -Message "Installation complete."
#>

param(
    [string]$Title   = 'TSScan Server',
    [string]$Message = ''
)

try {
    [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
    [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null

    $template = @"
<toast duration="long">
    <visual>
        <binding template="ToastGeneric">
            <text>$Title</text>
            <text>$Message</text>
        </binding>
    </visual>
</toast>
"@

    $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
    $xml.LoadXml($template)
    $toast = New-Object Windows.UI.Notifications.ToastNotification $xml
    [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('TSScan Server').Show($toast)
} catch {
    # Non-fatal - toast failure should not affect installation
    Write-Output "Toast notification failed: $_"
}
