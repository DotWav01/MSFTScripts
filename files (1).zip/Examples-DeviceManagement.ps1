<#
.SYNOPSIS
    Example usage scenarios for the Entra ID Device Management scripts.

.DESCRIPTION
    This script demonstrates common usage patterns and scenarios for device management.
    Run sections individually or uncomment specific examples to test functionality.

.NOTES
    File Name      : Examples-DeviceManagement.ps1
    Author         : IT Infrastructure Team
#>

# Ensure required modules are available
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.DeviceManagement)) {
    Write-Warning "Microsoft Graph modules not found. Installing..."
    Install-Module Microsoft.Graph.DeviceManagement, Microsoft.Graph.Authentication, Microsoft.Graph.Users -Force
}

Write-Host "Entra ID Device Management - Example Usage Scenarios" -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan

# Connect to Microsoft Graph (uncomment to run)
# Connect-MgGraph -Scopes "DeviceManagementManagedDevices.Read.All", "Device.Read.All", "User.Read.All"

#region Example 1: Basic Device Name Query
Write-Host "`n1. Basic Device Name Query" -ForegroundColor Green
Write-Host "   Query specific devices by name and export to CSV"

# Create sample device names file
$sampleDevices = @"
DeviceName
LAPTOP-001
DESKTOP-002
TABLET-003
"@
$sampleDevices | Out-File -FilePath "SampleDevices.csv" -Encoding UTF8

# Example command (uncomment to run)
# .\Get-EntraIDDeviceInfo.ps1 -Mode DeviceName -InputFile "SampleDevices.csv" -ExportFormat CSV

Write-Host "   Command: .\Get-EntraIDDeviceInfo.ps1 -Mode DeviceName -InputFile 'SampleDevices.csv'"
#endregion

#region Example 2: User Device Query with Filtering
Write-Host "`n2. User Device Query with OS Filtering" -ForegroundColor Green
Write-Host "   Get Windows devices for specific users"

# Create sample users file
$sampleUsers = @"
UserPrincipalName
john.doe@company.com
jane.smith@company.com
admin@company.com
"@
$sampleUsers | Out-File -FilePath "SampleUsers.csv" -Encoding UTF8

# Example command (uncomment to run)
# .\Get-EntraIDDeviceInfo.ps1 -Mode User -InputFile "SampleUsers.csv" -DeviceTypeFilter Windows -ExportFormat JSON

Write-Host "   Command: .\Get-EntraIDDeviceInfo.ps1 -Mode User -InputFile 'SampleUsers.csv' -DeviceTypeFilter Windows"
#endregion

#region Example 3: All Devices with Compliance
Write-Host "`n3. All Devices with Compliance Information" -ForegroundColor Green
Write-Host "   Get all iOS devices with compliance details"

# Example command (uncomment to run)
# .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter iOS -IncludeCompliance -ExportFormat HTML

Write-Host "   Command: .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter iOS -IncludeCompliance -ExportFormat HTML"
#endregion

#region Example 4: Comprehensive Export
Write-Host "`n4. Comprehensive Device Export" -ForegroundColor Green
Write-Host "   Export all devices to multiple formats with full details"

# Example command (uncomment to run)
# .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -IncludeCompliance -Detailed -ExportFormat All -OutputPath "C:\DeviceReports"

Write-Host "   Command: .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -IncludeCompliance -Detailed -ExportFormat All"
#endregion

#region Example 5: WhatIf Preview
Write-Host "`n5. Preview Mode (WhatIf)" -ForegroundColor Green
Write-Host "   Preview operations without actually executing"

# Example command (uncomment to run)
# .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter Android -WhatIf

Write-Host "   Command: .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter Android -WhatIf"
#endregion

#region Example 6: Helper Functions
Write-Host "`n6. Using Helper Functions" -ForegroundColor Green
Write-Host "   Advanced device management operations"

# Import helper functions (uncomment to run)
# . .\DeviceManagement-Helpers.ps1

# Generate device health report (uncomment to run)
# Get-DeviceHealthReport -OutputPath "C:\Reports"

# Analyze devices for cleanup (uncomment to run)
# Invoke-DeviceCleanup -InactiveDays 90 -WhatIf -ExportResults

# Get compliance details (uncomment to run)
# Get-DeviceComplianceDetails -AllDevices | Export-Csv "ComplianceReport.csv" -NoTypeInformation

# Create comprehensive inventory (uncomment to run)
# Export-DeviceInventory -OutputPath "C:\Inventory" -IncludeCompliance

Write-Host "   Examples:"
Write-Host "   - Get-DeviceHealthReport -OutputPath 'C:\Reports'"
Write-Host "   - Invoke-DeviceCleanup -InactiveDays 90 -WhatIf"
Write-Host "   - Export-DeviceInventory -IncludeCompliance"
#endregion

#region Example 7: Scheduled Task Scenarios
Write-Host "`n7. Scheduled Task Examples" -ForegroundColor Green
Write-Host "   Automated reporting scenarios"

Write-Host "   Daily compliance report:"
Write-Host "   .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -IncludeCompliance -ExportFormat CSV -OutputFileName 'Daily-Compliance-Report'"

Write-Host "`n   Weekly device inventory:"
Write-Host "   .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -Detailed -ExportFormat JSON -OutputFileName 'Weekly-Device-Inventory'"

Write-Host "`n   Monthly cleanup analysis:"
Write-Host "   . .\DeviceManagement-Helpers.ps1; Invoke-DeviceCleanup -InactiveDays 60 -ExportResults"
#endregion

#region Example 8: Enterprise Scenarios
Write-Host "`n8. Enterprise Scenarios" -ForegroundColor Green
Write-Host "   Large-scale enterprise operations"

Write-Host "   Audit all corporate Windows devices:"
Write-Host "   .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter Windows -IncludeCompliance -Detailed -ExportFormat HTML"

Write-Host "`n   BYOD device report (iOS/Android):"
Write-Host "   .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter iOS -ExportFormat CSV -OutputFileName 'BYOD-iOS-Report'"
Write-Host "   .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter Android -ExportFormat CSV -OutputFileName 'BYOD-Android-Report'"

Write-Host "`n   Executive summary report:"
Write-Host "   . .\DeviceManagement-Helpers.ps1; Get-DeviceHealthReport; Export-DeviceInventory -IncludeCompliance"
#endregion

#region Example 9: Error Handling and Troubleshooting
Write-Host "`n9. Error Handling Examples" -ForegroundColor Green
Write-Host "   Handling common issues"

Write-Host "   Test authentication first:"
Write-Host "   try { Get-MgContext } catch { Connect-MgGraph -Scopes 'Device.Read.All' }"

Write-Host "`n   Validate input files:"
Write-Host "   if (Test-Path 'devices.csv') { .\Get-EntraIDDeviceInfo.ps1 -Mode DeviceName -InputFile 'devices.csv' }"

Write-Host "`n   Handle large tenants:"
Write-Host "   .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter Windows -Verbose"
#endregion

#region Example 10: Custom Filtering and Processing
Write-Host "`n10. Custom Processing Examples" -ForegroundColor Green
Write-Host "    Post-processing exported data"

$customProcessingExample = @'
# After running device export, filter results
$devices = Import-Csv "EntraID-Devices-*.csv"

# Find devices not used in 30 days
$inactiveDevices = $devices | Where-Object {
    $_.ApproximateLastSignInDateTime -and
    [DateTime]$_.ApproximateLastSignInDateTime -lt (Get-Date).AddDays(-30)
}

# Group by department
$devicesByDepartment = $devices | Group-Object -Property UserDepartment

# Export filtered results
$inactiveDevices | Export-Csv "InactiveDevices.csv" -NoTypeInformation
'@

Write-Host "   Custom filtering example:"
Write-Host $customProcessingExample
#endregion

Write-Host "`n" -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "Examples complete. Uncomment sections to execute." -ForegroundColor Cyan
Write-Host "For detailed help: Get-Help .\Get-EntraIDDeviceInfo.ps1 -Full" -ForegroundColor Cyan
