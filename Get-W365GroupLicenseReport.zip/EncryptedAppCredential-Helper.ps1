<#
.SYNOPSIS
    Creates an encrypted credential file for app registration authentication.

.DESCRIPTION
    This helper script securely encrypts and stores app registration client secret
    using Windows DPAPI. The encrypted file can only be decrypted by the same user
    on the same machine.

.PARAMETER OutputPath
    Path where the encrypted credential file will be saved.

.PARAMETER ClientSecret
    The client secret from your app registration (will be prompted securely if not provided).

.EXAMPLE
    .\New-EncryptedAppCredential.ps1 -OutputPath "C:\Scripts\Config\AppCred_GraphReports.xml"

.NOTES
    Author: Alexander
    Version: 1.0
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$OutputPath,
    
    [Parameter(Mandatory = $false)]
    [SecureString]$ClientSecret
)

try {
    Write-Host "`nApp Registration Credential Encryption Tool" -ForegroundColor Cyan
    Write-Host "==========================================`n" -ForegroundColor Cyan
    
    # Prompt for client secret if not provided
    if (-not $ClientSecret) {
        $ClientSecret = Read-Host "Enter the App Registration Client Secret" -AsSecureString
    }
    
    # Create credential object
    $credObject = [PSCustomObject]@{
        ClientSecret = $ClientSecret
        CreatedDate = Get-Date
        CreatedBy = $env:USERNAME
        ComputerName = $env:COMPUTERNAME
    }
    
    # Ensure output directory exists
    $outputDir = Split-Path -Path $OutputPath -Parent
    if (-not (Test-Path -Path $outputDir)) {
        Write-Host "Creating directory: $outputDir" -ForegroundColor Yellow
        New-Item -Path $outputDir -ItemType Directory -Force | Out-Null
    }
    
    # Export encrypted credential
    Write-Host "Encrypting and saving credential..." -ForegroundColor Yellow
    $credObject | Export-Clixml -Path $OutputPath -Force
    
    # Set restrictive NTFS permissions (current user only)
    Write-Host "Setting file permissions..." -ForegroundColor Yellow
    $acl = Get-Acl -Path $OutputPath
    
    # Disable inheritance and remove existing permissions
    $acl.SetAccessRuleProtection($true, $false)
    
    # Add only current user with full control
    $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
        $currentUser,
        "FullControl",
        "Allow"
    )
    $acl.SetAccessRule($accessRule)
    Set-Acl -Path $OutputPath -AclObject $acl
    
    Write-Host "`nCredential encrypted successfully!" -ForegroundColor Green
    Write-Host "Output file: $OutputPath" -ForegroundColor Cyan
    Write-Host "Encrypted for user: $currentUser" -ForegroundColor Cyan
    Write-Host "On computer: $env:COMPUTERNAME`n" -ForegroundColor Cyan
    
    Write-Warning "This credential file can ONLY be decrypted by:"
    Write-Warning "  User: $currentUser"
    Write-Warning "  Computer: $env:COMPUTERNAME"
    
}
catch {
    Write-Error "Failed to create encrypted credential: $($_.Exception.Message)"
    exit 1
}