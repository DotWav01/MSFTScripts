#Requires -Modules Microsoft.Graph.DeviceManagement, Microsoft.Graph.Authentication

<#
.SYNOPSIS
    Advanced helper functions for Entra ID device management operations.

.DESCRIPTION
    This script provides additional utility functions for device management including:
    - Bulk device operations
    - Device health checks
    - Compliance reporting
    - Device lifecycle management

.NOTES
    File Name      : DeviceManagement-Helpers.ps1
    Author         : IT Infrastructure Team
    Prerequisite   : Microsoft Graph PowerShell SDK
#>

function Get-DeviceHealthReport {
    <#
    .SYNOPSIS
        Generates a comprehensive device health report.
    
    .DESCRIPTION
        Analyzes device compliance, last activity, and potential issues.
    
    .PARAMETER OutputPath
        Directory to save the health report.
    
    .EXAMPLE
        Get-DeviceHealthReport -OutputPath "C:\Reports"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$OutputPath = (Get-Location).Path
    )
    
    try {
        Write-Host "Generating device health report..." -ForegroundColor Green
        
        # Get all devices with extended properties
        $allDevices = Get-MgDevice -All -Select "id,displayName,operatingSystem,isCompliant,isManaged,approximateLastSignInDateTime,createdDateTime"
        
        $healthReport = @{
            TotalDevices = $allDevices.Count
            CompliantDevices = ($allDevices | Where-Object { $_.IsCompliant -eq $true }).Count
            ManagedDevices = ($allDevices | Where-Object { $_.IsManaged -eq $true }).Count
            InactiveDevices = @()
            OldDevices = @()
            UnmanagedDevices = @()
            ByOperatingSystem = @{}
        }
        
        # Analyze device statistics
        $thirtyDaysAgo = (Get-Date).AddDays(-30)
        $oneYearAgo = (Get-Date).AddYears(-1)
        
        foreach ($device in $allDevices) {
            # Check for inactive devices (no sign-in in 30 days)
            if ($device.ApproximateLastSignInDateTime -and 
                [DateTime]$device.ApproximateLastSignInDateTime -lt $thirtyDaysAgo) {
                $healthReport.InactiveDevices += $device
            }
            
            # Check for old devices (created more than 1 year ago, no recent activity)
            if ($device.CreatedDateTime -and 
                [DateTime]$device.CreatedDateTime -lt $oneYearAgo -and
                ($device.ApproximateLastSignInDateTime -and 
                 [DateTime]$device.ApproximateLastSignInDateTime -lt $thirtyDaysAgo)) {
                $healthReport.OldDevices += $device
            }
            
            # Check for unmanaged devices
            if (-not $device.IsManaged) {
                $healthReport.UnmanagedDevices += $device
            }
            
            # Group by OS
            $os = $device.OperatingSystem
            if (-not $healthReport.ByOperatingSystem.ContainsKey($os)) {
                $healthReport.ByOperatingSystem[$os] = 0
            }
            $healthReport.ByOperatingSystem[$os]++
        }
        
        # Generate report
        $reportFileName = "DeviceHealthReport-$(Get-Date -Format 'yyyyMMdd-HHmmss').json"
        $reportPath = Join-Path -Path $OutputPath -ChildPath $reportFileName
        
        $healthReport | ConvertTo-Json -Depth 10 | Out-File -FilePath $reportPath -Encoding UTF8
        
        Write-Host "Health report saved to: $reportPath" -ForegroundColor Green
        return $healthReport
    }
    catch {
        Write-Error "Error generating health report: $($_.Exception.Message)"
        throw
    }
}

function Invoke-DeviceCleanup {
    <#
    .SYNOPSIS
        Identifies devices that may need cleanup or attention.
    
    .DESCRIPTION
        Finds inactive, duplicate, or problematic devices for potential cleanup.
    
    .PARAMETER InactiveDays
        Number of days to consider a device inactive.
    
    .PARAMETER WhatIf
        Preview cleanup candidates without taking action.
    
    .EXAMPLE
        Invoke-DeviceCleanup -InactiveDays 90 -WhatIf
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory = $false)]
        [int]$InactiveDays = 90,
        
        [Parameter(Mandatory = $false)]
        [switch]$ExportResults
    )
    
    try {
        Write-Host "Analyzing devices for cleanup opportunities..." -ForegroundColor Yellow
        
        $cutoffDate = (Get-Date).AddDays(-$InactiveDays)
        $allDevices = Get-MgDevice -All -Select "id,displayName,operatingSystem,isCompliant,isManaged,approximateLastSignInDateTime,createdDateTime"
        
        $cleanupCandidates = @{
            InactiveDevices = @()
            DuplicateDevices = @()
            NeverUsedDevices = @()
            UnmanagedDevices = @()
        }
        
        # Find inactive devices
        $cleanupCandidates.InactiveDevices = $allDevices | Where-Object {
            $_.ApproximateLastSignInDateTime -and 
            [DateTime]$_.ApproximateLastSignInDateTime -lt $cutoffDate
        }
        
        # Find devices that have never been used
        $cleanupCandidates.NeverUsedDevices = $allDevices | Where-Object {
            -not $_.ApproximateLastSignInDateTime
        }
        
        # Find unmanaged devices
        $cleanupCandidates.UnmanagedDevices = $allDevices | Where-Object {
            -not $_.IsManaged
        }
        
        # Find potential duplicates (same display name)
        $deviceGroups = $allDevices | Group-Object -Property DisplayName | Where-Object { $_.Count -gt 1 }
        $cleanupCandidates.DuplicateDevices = $deviceGroups | ForEach-Object { $_.Group }
        
        # Display summary
        Write-Host "`nCleanup Analysis Summary:" -ForegroundColor Cyan
        Write-Host "Inactive Devices ($InactiveDays+ days): $($cleanupCandidates.InactiveDevices.Count)" -ForegroundColor Yellow
        Write-Host "Never Used Devices: $($cleanupCandidates.NeverUsedDevices.Count)" -ForegroundColor Yellow
        Write-Host "Unmanaged Devices: $($cleanupCandidates.UnmanagedDevices.Count)" -ForegroundColor Yellow
        Write-Host "Potential Duplicates: $($cleanupCandidates.DuplicateDevices.Count)" -ForegroundColor Yellow
        
        if ($ExportResults) {
            $exportPath = "DeviceCleanupCandidates-$(Get-Date -Format 'yyyyMMdd-HHmmss').json"
            $cleanupCandidates | ConvertTo-Json -Depth 10 | Out-File -FilePath $exportPath -Encoding UTF8
            Write-Host "Cleanup candidates exported to: $exportPath" -ForegroundColor Green
        }
        
        return $cleanupCandidates
    }
    catch {
        Write-Error "Error during device cleanup analysis: $($_.Exception.Message)"
        throw
    }
}

function Get-DeviceComplianceDetails {
    <#
    .SYNOPSIS
        Gets detailed compliance information for devices.
    
    .DESCRIPTION
        Retrieves comprehensive compliance status and policy details.
    
    .PARAMETER DeviceIds
        Array of device IDs to check compliance for.
    
    .PARAMETER AllDevices
        Check compliance for all devices in tenant.
    
    .EXAMPLE
        Get-DeviceComplianceDetails -AllDevices
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, ParameterSetName = 'Specific')]
        [string[]]$DeviceIds,
        
        [Parameter(Mandatory = $false, ParameterSetName = 'All')]
        [switch]$AllDevices
    )
    
    try {
        Write-Host "Retrieving device compliance details..." -ForegroundColor Green
        
        $complianceResults = @()
        
        if ($AllDevices) {
            $managedDevices = Get-MgDeviceManagementManagedDevice -All
        } else {
            $managedDevices = @()
            foreach ($deviceId in $DeviceIds) {
                $device = Get-MgDeviceManagementManagedDevice -Filter "azureADDeviceId eq '$deviceId'"
                if ($device) {
                    $managedDevices += $device
                }
            }
        }
        
        foreach ($device in $managedDevices) {
            try {
                # Get compliance policies applied to device
                $compliancePolicies = Get-MgDeviceManagementManagedDeviceCompliancePolicy -ManagedDeviceId $device.Id -ErrorAction SilentlyContinue
                
                $complianceDetail = [PSCustomObject]@{
                    DeviceId = $device.AzureADDeviceId
                    DeviceName = $device.DeviceName
                    UserPrincipalName = $device.UserPrincipalName
                    OperatingSystem = $device.OperatingSystem
                    ComplianceState = $device.ComplianceState
                    LastComplianceReportedDateTime = $device.ComplianceGracePeriodExpirationDateTime
                    IsEncrypted = $device.IsEncrypted
                    JailBroken = $device.JailBroken
                    ManagementAgent = $device.ManagementAgent
                    EnrolledDateTime = $device.EnrolledDateTime
                    LastSyncDateTime = $device.LastSyncDateTime
                    AppliedPoliciesCount = if ($compliancePolicies) { $compliancePolicies.Count } else { 0 }
                }
                
                $complianceResults += $complianceDetail
            }
            catch {
                Write-Warning "Error processing device $($device.DeviceName): $($_.Exception.Message)"
            }
        }
        
        Write-Host "Retrieved compliance details for $($complianceResults.Count) devices" -ForegroundColor Green
        return $complianceResults
    }
    catch {
        Write-Error "Error retrieving compliance details: $($_.Exception.Message)"
        throw
    }
}

function Export-DeviceInventory {
    <#
    .SYNOPSIS
        Creates a comprehensive device inventory export.
    
    .DESCRIPTION
        Generates a complete device inventory with all available information.
    
    .PARAMETER OutputPath
        Directory to save inventory files.
    
    .PARAMETER IncludeCompliance
        Include compliance information in inventory.
    
    .PARAMETER IncludeApps
        Include installed applications (may be slow for large tenants).
    
    .EXAMPLE
        Export-DeviceInventory -OutputPath "C:\DeviceInventory" -IncludeCompliance
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$OutputPath = (Get-Location).Path,
        
        [Parameter(Mandatory = $false)]
        [switch]$IncludeCompliance,
        
        [Parameter(Mandatory = $false)]
        [switch]$IncludeApps
    )
    
    try {
        Write-Host "Starting comprehensive device inventory..." -ForegroundColor Green
        
        $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
        $inventoryFolder = Join-Path -Path $OutputPath -ChildPath "DeviceInventory-$timestamp"
        New-Item -Path $inventoryFolder -ItemType Directory -Force | Out-Null
        
        # Get all devices
        Write-Host "Retrieving all devices..." -ForegroundColor Yellow
        $allDevices = Get-MgDevice -All
        
        # Basic device inventory
        $deviceInventory = @()
        $counter = 0
        
        foreach ($device in $allDevices) {
            $counter++
            Write-Progress -Activity "Processing Device Inventory" -Status "Processing $($device.DisplayName) ($counter of $($allDevices.Count))" -PercentComplete (($counter / $allDevices.Count) * 100)
            
            try {
                # Get device owner
                $registeredUsers = Get-MgDeviceRegisteredUser -DeviceId $device.Id -ErrorAction SilentlyContinue
                $ownerInfo = if ($registeredUsers) {
                    $user = Get-MgUser -UserId $registeredUsers[0].Id -Select "userPrincipalName,displayName,department" -ErrorAction SilentlyContinue
                    @{
                        UserPrincipalName = $user.UserPrincipalName
                        DisplayName = $user.DisplayName
                        Department = $user.Department
                    }
                } else {
                    @{
                        UserPrincipalName = "Not Found"
                        DisplayName = "Not Found"
                        Department = "Not Found"
                    }
                }
                
                $deviceRecord = [PSCustomObject]@{
                    DeviceId = $device.Id
                    DisplayName = $device.DisplayName
                    OperatingSystem = $device.OperatingSystem
                    OperatingSystemVersion = $device.OperatingSystemVersion
                    IsCompliant = $device.IsCompliant
                    IsManaged = $device.IsManaged
                    TrustType = $device.TrustType
                    ApproximateLastSignInDateTime = $device.ApproximateLastSignInDateTime
                    CreatedDateTime = $device.CreatedDateTime
                    UserPrincipalName = $ownerInfo.UserPrincipalName
                    UserDisplayName = $ownerInfo.DisplayName
                    UserDepartment = $ownerInfo.Department
                }
                
                $deviceInventory += $deviceRecord
            }
            catch {
                Write-Warning "Error processing device $($device.DisplayName): $($_.Exception.Message)"
            }
        }
        
        Write-Progress -Activity "Processing Device Inventory" -Completed
        
        # Export basic inventory
        $basicInventoryPath = Join-Path -Path $inventoryFolder -ChildPath "BasicDeviceInventory.csv"
        $deviceInventory | Export-Csv -Path $basicInventoryPath -NoTypeInformation
        Write-Host "Basic inventory exported to: $basicInventoryPath" -ForegroundColor Green
        
        # Export compliance details if requested
        if ($IncludeCompliance) {
            Write-Host "Generating compliance report..." -ForegroundColor Yellow
            $complianceDetails = Get-DeviceComplianceDetails -AllDevices
            $compliancePath = Join-Path -Path $inventoryFolder -ChildPath "ComplianceDetails.csv"
            $complianceDetails | Export-Csv -Path $compliancePath -NoTypeInformation
            Write-Host "Compliance report exported to: $compliancePath" -ForegroundColor Green
        }
        
        # Generate summary report
        $summaryReport = @{
            GeneratedDateTime = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            TotalDevices = $deviceInventory.Count
            DevicesByOS = ($deviceInventory | Group-Object -Property OperatingSystem | ForEach-Object { @{$_.Name = $_.Count} })
            ComplianceOverview = @{
                Compliant = ($deviceInventory | Where-Object { $_.IsCompliant -eq $true }).Count
                NonCompliant = ($deviceInventory | Where-Object { $_.IsCompliant -eq $false }).Count
                Unknown = ($deviceInventory | Where-Object { $_.IsCompliant -eq $null }).Count
            }
            ManagementOverview = @{
                Managed = ($deviceInventory | Where-Object { $_.IsManaged -eq $true }).Count
                Unmanaged = ($deviceInventory | Where-Object { $_.IsManaged -eq $false }).Count
            }
        }
        
        $summaryPath = Join-Path -Path $inventoryFolder -ChildPath "InventorySummary.json"
        $summaryReport | ConvertTo-Json -Depth 10 | Out-File -FilePath $summaryPath
        Write-Host "Summary report exported to: $summaryPath" -ForegroundColor Green
        
        Write-Host "Device inventory completed. Files saved to: $inventoryFolder" -ForegroundColor Green
        return $inventoryFolder
    }
    catch {
        Write-Error "Error creating device inventory: $($_.Exception.Message)"
        throw
    }
}

# Export functions for module usage
Export-ModuleMember -Function Get-DeviceHealthReport, Invoke-DeviceCleanup, Get-DeviceComplianceDetails, Export-DeviceInventory
