<#
.SYNOPSIS
    Generates a license report for Windows 365 Enterprise users across specified Entra ID groups.

.DESCRIPTION
    This script connects to Microsoft Graph using dual app registration authentication,
    retrieves members from specified Entra ID groups, filters for Windows 365 Enterprise
    license holders, and exports detailed user information including Employee ID.
    
    Uses two separate app registrations:
    - UserGroupApp: For User.Read.All and Group.Read.All operations
    - DirectoryApp: For Directory.Read.All operations (license details)
    
    Authentication credentials are loaded from encrypted XML files for security.
    Group lists and configuration settings are managed through a JSON config file.

.PARAMETER ConfigPath
    Path to the JSON configuration file. Defaults to .\GroupLicenseConfig.json

.PARAMETER SkipLicenseFilter
    Switch to disable Windows 365 license filtering and show all users.

.EXAMPLE
    .\Get-W365GroupLicenseReport.ps1
    
    Runs the script using default config file location.

.EXAMPLE
    .\Get-W365GroupLicenseReport.ps1 -ConfigPath "C:\Scripts\Config\MyConfig.json"
    
    Runs the script with a custom configuration file.

.EXAMPLE
    .\Get-W365GroupLicenseReport.ps1 -SkipLicenseFilter
    
    Runs the script but includes all users regardless of license type.

.NOTES
    Author: Alexander
    Version: 2.1
    Requires: Microsoft.Graph.Authentication, Microsoft.Graph.Groups, Microsoft.Graph.Users modules
    
    Required App Registration Permissions:
    UserGroupApp:
    - User.Read.All
    - Group.Read.All
    
    DirectoryApp:
    - Directory.Read.All

.LINK
    https://learn.microsoft.com/en-us/graph/api/user-get
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$ConfigPath = ".\GroupLicenseConfig.json",
    
    [Parameter(Mandatory = $false)]
    [switch]$SkipLicenseFilter
)

#Requires -Modules Microsoft.Graph.Authentication, Microsoft.Graph.Groups, Microsoft.Graph.Users

#region Functions

function Import-EncryptedCredential {
    <#
    .SYNOPSIS
        Imports encrypted credential from XML file.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )
    
    try {
        if (-not (Test-Path -Path $Path)) {
            throw "Encrypted credential file not found: $Path"
        }
        
        $encryptedCred = Import-Clixml -Path $Path
        
        # Validate the imported object has the required property
        if (-not $encryptedCred.ClientSecret) {
            throw "Invalid credential file format. Missing ClientSecret property."
        }
        
        Write-Verbose "Successfully imported encrypted credential from: $Path"
        return $encryptedCred
    }
    catch {
        Write-Error "Failed to import encrypted credential: $($_.Exception.Message)"
        throw
    }
}

function Connect-MgGraphWithApp {
    <#
    .SYNOPSIS
        Connects to Microsoft Graph using app registration credentials.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TenantId,
        
        [Parameter(Mandatory = $true)]
        [string]$ClientId,
        
        [Parameter(Mandatory = $true)]
        [securestring]$ClientSecret,
        
        [Parameter(Mandatory = $false)]
        [string]$AppName = "App"
    )
    
    try {
        Write-Verbose "Connecting to Microsoft Graph with $AppName..."
        
        # Convert SecureString to plain text for the credential object
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ClientSecret)
        $plainSecret = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
        
        # Create credential object
        $securePassword = ConvertTo-SecureString $plainSecret -AsPlainText -Force
        $credential = New-Object System.Management.Automation.PSCredential($ClientId, $securePassword)
        
        # Connect using client credentials
        Connect-MgGraph -TenantId $TenantId -ClientSecretCredential $credential -NoWelcome
        
        Write-Host "Successfully connected to Microsoft Graph ($AppName)" -ForegroundColor Green
        
        # Clear sensitive variables
        $plainSecret = $null
        $securePassword = $null
        $credential = $null
    }
    catch {
        Write-Error "Failed to connect to Microsoft Graph with $AppName : $($_.Exception.Message)"
        throw
    }
}

function Get-GroupByIdentifier {
    <#
    .SYNOPSIS
        Retrieves an Entra ID group by display name or object ID.
        Uses the currently connected Graph session (UserGroupApp).
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Identifier
    )
    
    try {
        Write-Verbose "Searching for group: $Identifier"
        
        $group = $null
        
        # First try by display name
        try {
            $groups = Get-MgGroup -Filter "displayName eq '$Identifier'" -ErrorAction Stop
            
            if ($groups.Count -eq 1) {
                $group = $groups[0]
                Write-Verbose "Found group by display name: $($group.DisplayName)"
            }
            elseif ($groups.Count -gt 1) {
                Write-Warning "Multiple groups found with display name '$Identifier'. Using first match."
                Write-Warning "Consider using Object ID for precise matching."
                $group = $groups[0]
            }
        }
        catch {
            Write-Verbose "Display name search failed, attempting Object ID search..."
        }
        
        # If not found by display name, try by Object ID
        if (-not $group) {
            try {
                $group = Get-MgGroup -GroupId $Identifier -ErrorAction Stop
                Write-Verbose "Found group by Object ID: $($group.DisplayName)"
            }
            catch {
                Write-Warning "Group not found with identifier: $Identifier"
                return $null
            }
        }
        
        return $group
    }
    catch {
        Write-Error "Error retrieving group: $($_.Exception.Message)"
        return $null
    }
}

function Get-UserDetailsWithUserApp {
    <#
    .SYNOPSIS
        Retrieves user details using UserGroupApp connection.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$UserId
    )
    
    try {
        $user = Get-MgUser -UserId $UserId `
                           -Property "DisplayName,UserPrincipalName,Mail,Department,EmployeeId" `
                           -ErrorAction Stop
        return $user
    }
    catch {
        Write-Warning "Failed to retrieve user details for $UserId : $($_.Exception.Message)"
        throw
    }
}

function Get-UserLicenseDetailsWithDirectoryApp {
    <#
    .SYNOPSIS
        Retrieves and formats user license information using DirectoryApp connection.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$UserId,
        
        [Parameter(Mandatory = $false)]
        [string[]]$FilterPrefixes
    )
    
    try {
        $userLicenses = Get-MgUserLicenseDetail -UserId $UserId -ErrorAction Stop
        
        $allLicenses = @()
        $filteredLicenses = @()
        
        foreach ($license in $userLicenses) {
            $allLicenses += $license.SkuPartNumber
            
            # Check if license matches any filter prefix
            if ($FilterPrefixes) {
                foreach ($prefix in $FilterPrefixes) {
                    if ($license.SkuPartNumber -like "$prefix*") {
                        $filteredLicenses += $license.SkuPartNumber
                        break
                    }
                }
            }
        }
        
        return @{
            AllLicenses = $allLicenses
            FilteredLicenses = $filteredLicenses
            HasFilteredLicense = ($filteredLicenses.Count -gt 0)
        }
    }
    catch {
        Write-Warning "Failed to retrieve licenses for user $UserId : $($_.Exception.Message)"
        return @{
            AllLicenses = @()
            FilteredLicenses = @()
            HasFilteredLicense = $false
        }
    }
}

function Switch-MgGraphContext {
    <#
    .SYNOPSIS
        Switches between app registration contexts by disconnecting and reconnecting.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet('UserGroup', 'Directory')]
        [string]$TargetApp,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$AppConfigs
    )
    
    try {
        # Disconnect current session
        if (Get-MgContext) {
            Disconnect-MgGraph | Out-Null
        }
        
        # Connect to target app
        $targetConfig = $AppConfigs[$TargetApp]
        
        Connect-MgGraphWithApp -TenantId $targetConfig.TenantId `
                               -ClientId $targetConfig.ClientId `
                               -ClientSecret $targetConfig.ClientSecret `
                               -AppName $targetConfig.AppName
    }
    catch {
        Write-Error "Failed to switch to $TargetApp app context: $($_.Exception.Message)"
        throw
    }
}

#endregion Functions

#region Main Script

try {
    # Start script execution
    Write-Host "`n================================" -ForegroundColor Cyan
    Write-Host "Windows 365 License Report Tool" -ForegroundColor Cyan
    Write-Host "Dual App Registration Mode" -ForegroundColor Cyan
    Write-Host "================================`n" -ForegroundColor Cyan
    
    # Load configuration file
    Write-Host "Loading configuration..." -ForegroundColor Yellow
    
    if (-not (Test-Path -Path $ConfigPath)) {
        throw "Configuration file not found: $ConfigPath"
    }
    
    $config = Get-Content -Path $ConfigPath -Raw | ConvertFrom-Json
    Write-Host "Configuration loaded successfully" -ForegroundColor Green
    
    # Import encrypted credentials for both apps
    Write-Host "`nImporting encrypted credentials..." -ForegroundColor Yellow
    
    Write-Host "  - UserGroup App credentials..." -ForegroundColor Gray
    $userGroupCred = Import-EncryptedCredential -Path $config.AppRegistrations.UserGroupApp.EncryptedCredentialPath
    
    Write-Host "  - Directory App credentials..." -ForegroundColor Gray
    $directoryCred = Import-EncryptedCredential -Path $config.AppRegistrations.DirectoryApp.EncryptedCredentialPath
    
    Write-Host "Credentials imported successfully" -ForegroundColor Green
    
    # Store app configurations for context switching
    $appConfigs = @{
        UserGroup = @{
            TenantId = $config.AppRegistrations.UserGroupApp.TenantId
            ClientId = $config.AppRegistrations.UserGroupApp.ClientId
            ClientSecret = $userGroupCred.ClientSecret
            AppName = "UserGroup App"
        }
        Directory = @{
            TenantId = $config.AppRegistrations.DirectoryApp.TenantId
            ClientId = $config.AppRegistrations.DirectoryApp.ClientId
            ClientSecret = $directoryCred.ClientSecret
            AppName = "Directory App"
        }
    }
    
    # Initial connection with UserGroupApp (for group and user operations)
    Write-Host "`nConnecting to Microsoft Graph..." -ForegroundColor Yellow
    Write-Host "Initial connection: UserGroup App" -ForegroundColor Gray
    
    Connect-MgGraphWithApp -TenantId $appConfigs.UserGroup.TenantId `
                           -ClientId $appConfigs.UserGroup.ClientId `
                           -ClientSecret $appConfigs.UserGroup.ClientSecret `
                           -AppName "UserGroup App"
    
    # Verify connection
    $context = Get-MgContext
    Write-Host "Connected to tenant: $($context.TenantId)" -ForegroundColor Green
    Write-Host "App ID: $($context.ClientId)" -ForegroundColor Green
    Write-Host "App Name: UserGroup App`n" -ForegroundColor Green
    
    # Determine license filter settings
    $useLicenseFilter = (-not $SkipLicenseFilter) -and $config.LicenseFilter.FilterEnabled
    $licenseFilterPrefixes = if ($useLicenseFilter) { $config.LicenseFilter.SkuPrefixes } else { @() }
    
    if ($useLicenseFilter) {
        Write-Host "License filter ENABLED - Filtering for: $($licenseFilterPrefixes -join ', ')" -ForegroundColor Cyan
    }
    else {
        Write-Host "License filter DISABLED - Including all users" -ForegroundColor Cyan
    }
    
    # Initialize results array
    $allResults = @()
    $groupProcessCount = 0
    $totalUsersProcessed = 0
    
    # Process each group from configuration
    Write-Host "`nProcessing $($config.Groups.Count) group(s)..." -ForegroundColor Yellow
    
    foreach ($groupIdentifier in $config.Groups) {
        $groupProcessCount++
        Write-Host "`n--- Processing Group $groupProcessCount of $($config.Groups.Count) ---" -ForegroundColor Magenta
        Write-Host "Group: $groupIdentifier" -ForegroundColor White
        
        # Ensure we're using UserGroupApp for group operations
        $currentContext = Get-MgContext
        if ($currentContext.ClientId -ne $appConfigs.UserGroup.ClientId) {
            Write-Verbose "Switching to UserGroup App for group operations..."
            Switch-MgGraphContext -TargetApp 'UserGroup' -AppConfigs $appConfigs
        }
        
        # Get the group
        $group = Get-GroupByIdentifier -Identifier $groupIdentifier
        
        if (-not $group) {
            Write-Warning "Skipping group: $groupIdentifier (not found)"
            continue
        }
        
        Write-Host "Found: $($group.DisplayName) (ID: $($group.Id))" -ForegroundColor Green
        
        # Get group members
        Write-Host "Retrieving group members..." -ForegroundColor Yellow
        $groupMembers = Get-MgGroupMember -GroupId $group.Id -All
        
        # Filter for users only
        $userMembers = $groupMembers | Where-Object { $_.AdditionalProperties.'@odata.type' -eq '#microsoft.graph.user' }
        
        Write-Host "Found $($userMembers.Count) user member(s)" -ForegroundColor Green
        
        if ($userMembers.Count -eq 0) {
            Write-Warning "No users found in group: $($group.DisplayName)"
            continue
        }
        
        # Process each user
        $userCounter = 0
        foreach ($member in $userMembers) {
            $userCounter++
            $totalUsersProcessed++
            
            Write-Progress -Activity "Processing Group: $($group.DisplayName)" `
                          -Status "User $userCounter of $($userMembers.Count)" `
                          -PercentComplete (($userCounter / $userMembers.Count) * 100)
            
            try {
                # Get user details using UserGroupApp
                $currentContext = Get-MgContext
                if ($currentContext.ClientId -ne $appConfigs.UserGroup.ClientId) {
                    Write-Verbose "Switching to UserGroup App for user details..."
                    Switch-MgGraphContext -TargetApp 'UserGroup' -AppConfigs $appConfigs
                }
                
                $user = Get-UserDetailsWithUserApp -UserId $member.Id
                
                # Switch to DirectoryApp for license details
                Write-Verbose "Switching to Directory App for license details..."
                Switch-MgGraphContext -TargetApp 'Directory' -AppConfigs $appConfigs
                
                # Get license details using DirectoryApp
                $licenseInfo = Get-UserLicenseDetailsWithDirectoryApp -UserId $member.Id -FilterPrefixes $licenseFilterPrefixes
                
                # Apply license filter if enabled
                if ($useLicenseFilter -and -not $licenseInfo.HasFilteredLicense) {
                    Write-Verbose "Skipping user $($user.UserPrincipalName) - No matching licenses"
                    continue
                }
                
                # Format license strings
                $allLicensesString = if ($licenseInfo.AllLicenses.Count -gt 0) {
                    $licenseInfo.AllLicenses -join "; "
                } else {
                    "No licenses assigned"
                }
                
                $w365LicensesString = if ($licenseInfo.FilteredLicenses.Count -gt 0) {
                    $licenseInfo.FilteredLicenses -join "; "
                } else {
                    "None"
                }
                
                # Create result object
                $userResult = [PSCustomObject]@{
                    DisplayName          = $user.DisplayName
                    UserPrincipalName    = $user.UserPrincipalName
                    Email                = $user.Mail
                    EmployeeId           = $user.EmployeeId
                    Department           = $user.Department
                    Windows365Licenses   = $w365LicensesString
                    AllLicenses          = $allLicensesString
                    GroupName            = $group.DisplayName
                    GroupId              = $group.Id
                }
                
                $allResults += $userResult
                
            }
            catch {
                Write-Warning "Failed to process user $($member.Id): $($_.Exception.Message)"
                
                # Add error record
                $errorResult = [PSCustomObject]@{
                    DisplayName          = "ERROR: Unable to retrieve"
                    UserPrincipalName    = $member.Id
                    Email                = "ERROR"
                    EmployeeId           = "ERROR"
                    Department           = "ERROR"
                    Windows365Licenses   = "ERROR"
                    AllLicenses          = "ERROR: $($_.Exception.Message)"
                    GroupName            = $group.DisplayName
                    GroupId              = $group.Id
                }
                $allResults += $errorResult
            }
        }
        
        Write-Progress -Activity "Processing Group: $($group.DisplayName)" -Completed
    }
    
    # Generate output
    if ($allResults.Count -eq 0) {
        Write-Warning "`nNo results to export. No users matched the criteria."
    }
    else {
        # Ensure output directory exists
        $outputDir = $config.OutputSettings.OutputDirectory
        if (-not (Test-Path -Path $outputDir)) {
            Write-Host "`nCreating output directory: $outputDir" -ForegroundColor Yellow
            New-Item -Path $outputDir -ItemType Directory -Force | Out-Null
        }
        
        # Generate output filename
        $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $fileName = "$($config.OutputSettings.FileNamePrefix)_$timestamp.csv"
        $outputPath = Join-Path -Path $outputDir -ChildPath $fileName
        
        # Export to CSV
        Write-Host "`nExporting results to CSV..." -ForegroundColor Yellow
        $allResults | Export-Csv -Path $outputPath -NoTypeInformation -Encoding UTF8
        
        # Display summary
        Write-Host "`n================================" -ForegroundColor Green
        Write-Host "Report Completed Successfully!" -ForegroundColor Green
        Write-Host "================================" -ForegroundColor Green
        Write-Host "Groups processed: $groupProcessCount" -ForegroundColor Cyan
        Write-Host "Total users evaluated: $totalUsersProcessed" -ForegroundColor Cyan
        Write-Host "Users in report: $($allResults.Count)" -ForegroundColor Cyan
        
        if ($useLicenseFilter) {
            Write-Host "Filter applied: Windows 365 Enterprise licenses only" -ForegroundColor Cyan
        }
        
        Write-Host "`nOutput file: $fileName" -ForegroundColor Yellow
        Write-Host "Full path: $outputPath" -ForegroundColor Yellow
        
        # Show preview
        Write-Host "`nPreview of results (first 10):" -ForegroundColor Magenta
        $allResults | Select-Object -First 10 DisplayName, UserPrincipalName, EmployeeId, Windows365Licenses | 
            Format-Table -AutoSize
        
        if ($allResults.Count -gt 10) {
            Write-Host "... and $($allResults.Count - 10) more user(s)" -ForegroundColor Gray
        }
    }
}
catch {
    Write-Error "`nScript execution failed: $($_.Exception.Message)"
    Write-Error $_.ScriptStackTrace
    exit 1
}
finally {
    # Disconnect from Microsoft Graph
    if (Get-MgContext) {
        Write-Host "`nDisconnecting from Microsoft Graph..." -ForegroundColor Yellow
        Disconnect-MgGraph | Out-Null
        Write-Host "Disconnected successfully" -ForegroundColor Green
    }
}

Write-Host "`nScript execution completed." -ForegroundColor Green
Write-Host "================================`n" -ForegroundColor Cyan

#endregion Main Script