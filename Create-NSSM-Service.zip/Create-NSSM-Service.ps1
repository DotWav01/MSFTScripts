#Requires -Version 5.1 -RunAsAdministrator
<#
.SYNOPSIS
Creates an NSSM Windows Service for ContinuousScriptRunner (for existing NSSM installations).

.DESCRIPTION
This script assumes you already have NSSM installed and creates a Windows Service
to run your PowerShell scripts continuously in the background.

.PARAMETER ScriptPath
Path to the PowerShell script to run as a service

.PARAMETER ServiceName
Name for the Windows service (default: auto-generated)

.PARAMETER ScriptParameters
Parameters to pass to the target script

.PARAMETER IntervalHours
Hours between executions (for interval mode)

.PARAMETER IntervalMinutes
Minutes between executions (for interval mode)

.PARAMETER ScheduledDays
Days of the week to run (for scheduled mode)

.PARAMETER ScheduledTimes
Times to run each scheduled day (for scheduled mode)

.PARAMETER NSSMPath
Full path to nssm.exe (will auto-detect if not specified)

.PARAMETER StartService
Start the service immediately after creation

.PARAMETER LogLevel
Logging level for the runner (DEBUG, INFO, WARN, ERROR)

.EXAMPLE
# Basic usage (auto-detects NSSM location)
.\Create-NSSM-Service.ps1 -ScriptPath "C:\Scripts\MyScript.ps1" -StartService

.EXAMPLE
# With config file parameter
$params = @{ ConfigPath = "C:\Scripts\config.json"; TenantId = "abc123" }
.\Create-NSSM-Service.ps1 -ScriptPath "C:\Scripts\MyScript.ps1" -ScriptParameters $params -IntervalHours 4

.EXAMPLE
# Scheduled execution with specific NSSM path
.\Create-NSSM-Service.ps1 -ScriptPath "C:\Scripts\MyScript.ps1" -ScheduledDays @("Monday","Friday") -ScheduledTimes @("09:00") -NSSMPath "C:\Tools\nssm\nssm.exe"

.EXAMPLE
# Quick setup for existing GroupQuery script
$params = @{ ConfigPath = ".\config.json" }
.\Create-NSSM-Service.ps1 -ScriptPath "C:\Scripts\GroupQuery.ps1" -ScriptParameters $params -ServiceName "GroupQuery-Service" -IntervalHours 2 -StartService

.NOTES
Requires:
- Administrator privileges
- NSSM already installed on the system
- ContinuousScriptRunner.ps1 accessible
#>

param(
    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_ -PathType Leaf})]
    [string]$ScriptPath,
    
    [Parameter(Mandatory=$false)]
    [string]$ServiceName,
    
    [Parameter(Mandatory=$false)]
    [hashtable]$ScriptParameters = @{},
    
    [Parameter(Mandatory=$false)]
    [int]$IntervalHours = 1,
    
    [Parameter(Mandatory=$false)]
    [int]$IntervalMinutes = 0,
    
    [Parameter(Mandatory=$false)]
    [string[]]$ScheduledDays,
    
    [Parameter(Mandatory=$false)]
    [string[]]$ScheduledTimes,
    
    [Parameter(Mandatory=$false)]
    [string]$NSSMPath,
    
    [Parameter(Mandatory=$false)]
    [switch]$StartService,
    
    [Parameter(Mandatory=$false)]
    [ValidateSet("DEBUG","INFO","WARN","ERROR")]
    [string]$LogLevel = "INFO"
)

function Test-AdminPrivileges {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-NSSM {
    param([string]$SpecifiedPath)
    
    # If a specific path was provided, check it first
    if (![string]::IsNullOrEmpty($SpecifiedPath)) {
        if (Test-Path $SpecifiedPath) {
            return $SpecifiedPath
        } else {
            Write-Warning "Specified NSSM path not found: $SpecifiedPath"
        }
    }
    
    # Check if NSSM is in PATH
    try {
        $pathNSSM = Get-Command nssm -ErrorAction SilentlyContinue
        if ($pathNSSM) {
            Write-Host "✓ Found NSSM in PATH: $($pathNSSM.Source)" -ForegroundColor Green
            return $pathNSSM.Source
        }
    } catch {}
    
    # Check common installation locations
    $commonLocations = @(
        "C:\Tools\nssm\nssm.exe",
        "C:\Tools\nssm\win64\nssm.exe",
        "C:\Tools\nssm\win32\nssm.exe",
        "C:\Program Files\nssm\nssm.exe",
        "C:\Program Files (x86)\nssm\nssm.exe",
        "C:\nssm\nssm.exe",
        "$env:USERPROFILE\Tools\nssm\nssm.exe"
    )
    
    foreach ($location in $commonLocations) {
        if (Test-Path $location) {
            Write-Host "✓ Found NSSM at: $location" -ForegroundColor Green
            return $location
        }
    }
    
    return $null
}

function Get-ContinuousRunnerPath {
    $locations = @(
        (Join-Path $PSScriptRoot "ContinuousScriptRunner.ps1"),
        (Join-Path (Split-Path $PSScriptRoot -Parent) "ContinuousScriptRunner.ps1"),
        "C:\Scripts\ContinuousRunner\ContinuousScriptRunner.ps1",
        "C:\Scripts\ContinuousScriptRunner.ps1"
    )
    
    foreach ($location in $locations) {
        if (Test-Path $location) {
            return $location
        }
    }
    
    throw "ContinuousScriptRunner.ps1 not found in expected locations. Please ensure it's accessible."
}

function Build-ServiceArguments {
    param(
        [string]$RunnerPath,
        [string]$ScriptPath,
        [hashtable]$ScriptParameters,
        [int]$IntervalHours,
        [int]$IntervalMinutes,
        [string[]]$ScheduledDays,
        [string[]]$ScheduledTimes,
        [string]$LogLevel
    )
    
    $arguments = @()
    $arguments += "-ExecutionPolicy Bypass"
    $arguments += "-WindowStyle Hidden"
    $arguments += "-NonInteractive"
    $arguments += "-File `"$RunnerPath`""
    $arguments += "-ScriptPath `"$ScriptPath`""
    
    # Add scheduling parameters
    if ($ScheduledDays -and $ScheduledTimes) {
        $daysString = ($ScheduledDays | ForEach-Object { "`"$_`"" }) -join ","
        $timesString = ($ScheduledTimes | ForEach-Object { "`"$_`"" }) -join ","
        $arguments += "-ScheduledDays @($daysString)"
        $arguments += "-ScheduledTimes @($timesString)"
    } else {
        if ($IntervalHours -gt 0) { $arguments += "-IntervalHours $IntervalHours" }
        if ($IntervalMinutes -gt 0) { $arguments += "-IntervalMinutes $IntervalMinutes" }
    }
    
    # Add script parameters
    if ($ScriptParameters.Count -gt 0) {
        $paramString = "@{"
        $paramPairs = foreach ($key in $ScriptParameters.Keys) {
            $value = $ScriptParameters[$key]
            if ($value -is [string]) {
                "$key=`"$value`""
            } elseif ($value -is [bool]) {
                "$key=`$$value"
            } else {
                "$key=$value"
            }
        }
        $paramString += ($paramPairs -join ";") + "}"
        $arguments += "-ScriptParameters $paramString"
    }
    
    # Add log level
    $arguments += "-LogLevel $LogLevel"
    
    return $arguments -join " "
}

function Remove-ExistingService {
    param([string]$NSSMExe, [string]$ServiceName)
    
    try {
        # Check if service exists
        $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if ($service) {
            Write-Host "Found existing service: $ServiceName" -ForegroundColor Yellow
            
            # Stop service if running
            if ($service.Status -eq "Running") {
                Write-Host "Stopping existing service..." -ForegroundColor Yellow
                & $NSSMExe stop $ServiceName
                Start-Sleep -Seconds 3
            }
            
            # Remove service
            Write-Host "Removing existing service..." -ForegroundColor Yellow
            & $NSSMExe remove $ServiceName confirm
            Start-Sleep -Seconds 2
            
            Write-Host "✓ Existing service removed" -ForegroundColor Green
        }
    }
    catch {
        Write-Warning "Could not remove existing service: $($_.Exception.Message)"
    }
}

function New-NSSMService {
    param(
        [string]$NSSMExe,
        [string]$ServiceName,
        [string]$ServiceArgs,
        [string]$ScriptPath
    )
    
    try {
        # Install new service
        Write-Host "Installing service: $ServiceName" -ForegroundColor Yellow
        $result = & $NSSMExe install $ServiceName "powershell.exe" 2>&1
        
        if ($LASTEXITCODE -ne 0) {
            throw "NSSM install failed (exit code: $LASTEXITCODE): $result"
        }
        
        # Configure service arguments
        Write-Host "Setting service arguments..." -ForegroundColor Yellow
        & $NSSMExe set $ServiceName Arguments $ServiceArgs
        
        # Configure additional service properties
        $scriptDirectory = Split-Path $ScriptPath -Parent
        $scriptName = Split-Path $ScriptPath -Leaf
        
        & $NSSMExe set $ServiceName AppDirectory "`"$scriptDirectory`""
        & $NSSMExe set $ServiceName DisplayName "$ServiceName (PowerShell Script Runner)"
        & $NSSMExe set $ServiceName Description "Continuous execution of PowerShell script: $scriptName"
        
        # Configure service recovery and logging
        Write-Host "Configuring service recovery options..." -ForegroundColor Yellow
        
        # Service recovery settings
        & $NSSMExe set $ServiceName AppRestartDelay 60000        # 1 minute delay before restart
        & $NSSMExe set $ServiceName AppStopMethodSkip 0          # Don't skip any stop methods
        & $NSSMExe set $ServiceName AppExit Default Restart      # Restart on any exit
        
        # Logging configuration
        $logsDir = "C:\Logs"
        if (!(Test-Path $logsDir)) {
            New-Item -ItemType Directory -Path $logsDir -Force | Out-Null
            Write-Host "✓ Created logs directory: $logsDir" -ForegroundColor Green
        }
        
        & $NSSMExe set $ServiceName AppStdout "$logsDir\$ServiceName-stdout.log"
        & $NSSMExe set $ServiceName AppStderr "$logsDir\$ServiceName-stderr.log"
        & $NSSMExe set $ServiceName AppRotateFiles 1             # Enable log rotation
        & $NSSMExe set $ServiceName AppRotateOnline 1            # Rotate while running
        & $NSSMExe set $ServiceName AppRotateSeconds 86400       # Daily rotation
        & $NSSMExe set $ServiceName AppRotateBytes 10485760      # 10MB max file size
        
        Write-Host "✓ Service configured successfully" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Failed to create NSSM service: $($_.Exception.Message)"
        return $false
    }
}

# Main execution
try {
    Write-Host "=== CREATE NSSM SERVICE FOR CONTINUOUS SCRIPT RUNNER ===" -ForegroundColor Cyan
    Write-Host ""
    
    # Check admin privileges
    if (!(Test-AdminPrivileges)) {
        throw "Administrator privileges are required. Please run PowerShell as Administrator."
    }
    
    # Generate service name if not provided
    if ([string]::IsNullOrEmpty($ServiceName)) {
        $scriptName = [System.IO.Path]::GetFileNameWithoutExtension((Split-Path $ScriptPath -Leaf))
        $ServiceName = "ScriptRunner-$scriptName"
    }
    
    # Display configuration
    Write-Host "Configuration:" -ForegroundColor Yellow
    Write-Host "  Service Name: $ServiceName"
    Write-Host "  Script Path: $ScriptPath"
    if ($ScriptParameters.Count -gt 0) {
        Write-Host "  Script Parameters:"
        foreach ($key in $ScriptParameters.Keys) {
            Write-Host "    $key = $($ScriptParameters[$key])"
        }
    }
    
    if ($ScheduledDays -and $ScheduledTimes) {
        Write-Host "  Schedule: $($ScheduledDays -join ', ') at $($ScheduledTimes -join ', ')"
    } else {
        $totalMinutes = ($IntervalHours * 60) + $IntervalMinutes
        Write-Host "  Interval: $totalMinutes minutes"
    }
    Write-Host ""
    
    # Find NSSM
    $nssmExe = Find-NSSM -SpecifiedPath $NSSMPath
    if (!$nssmExe) {
        throw @"
NSSM not found. Please ensure NSSM is installed and accessible.

Download from: https://nssm.cc/download
Or specify the path: -NSSMPath "C:\Path\To\nssm.exe"

Common locations to check:
- C:\Tools\nssm\nssm.exe
- C:\Program Files\nssm\nssm.exe
"@
    }
    
    Write-Host "Using NSSM: $nssmExe" -ForegroundColor Green
    
    # Verify NSSM version
    try {
        $nssmVersion = & $nssmExe --version 2>&1
        Write-Host "NSSM Version: $nssmVersion" -ForegroundColor Gray
    } catch {
        Write-Host "NSSM version check failed, continuing anyway..." -ForegroundColor Yellow
    }
    Write-Host ""
    
    # Find ContinuousScriptRunner
    $runnerPath = Get-ContinuousRunnerPath
    Write-Host "Using Runner: $runnerPath" -ForegroundColor Green
    Write-Host ""
    
    # Build service arguments
    $serviceArgs = Build-ServiceArguments -RunnerPath $runnerPath -ScriptPath $ScriptPath -ScriptParameters $ScriptParameters -IntervalHours $IntervalHours -IntervalMinutes $IntervalMinutes -ScheduledDays $ScheduledDays -ScheduledTimes $ScheduledTimes -LogLevel $LogLevel
    
    Write-Host "PowerShell Command:" -ForegroundColor Gray
    Write-Host "powershell.exe $serviceArgs" -ForegroundColor DarkGray
    Write-Host ""
    
    # Remove existing service if it exists
    Remove-ExistingService -NSSMExe $nssmExe -ServiceName $ServiceName
    
    # Create the service
    $success = New-NSSMService -NSSMExe $nssmExe -ServiceName $ServiceName -ServiceArgs $serviceArgs -ScriptPath $ScriptPath
    
    if (!$success) {
        throw "Failed to create service"
    }
    
    # Start service if requested
    if ($StartService) {
        Write-Host "Starting service..." -ForegroundColor Yellow
        $startResult = & $nssmExe start $ServiceName 2>&1
        
        Start-Sleep -Seconds 3
        
        # Check service status
        $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if ($service -and $service.Status -eq "Running") {
            Write-Host "✅ Service started successfully!" -ForegroundColor Green
        } else {
            Write-Host "⚠️ Service created but may not be running properly" -ForegroundColor Yellow
            Write-Host "Start Result: $startResult" -ForegroundColor Yellow
            Write-Host "Current Status: $($service.Status)" -ForegroundColor Yellow
        }
    }
    
    Write-Host ""
    Write-Host "=== SERVICE MANAGEMENT ===" -ForegroundColor Cyan
    Write-Host "Service created successfully: $ServiceName"
    Write-Host ""
    Write-Host "NSSM Commands:" -ForegroundColor Yellow
    Write-Host "  Status:   nssm status `"$ServiceName`""
    Write-Host "  Start:    nssm start `"$ServiceName`""
    Write-Host "  Stop:     nssm stop `"$ServiceName`""
    Write-Host "  Restart:  nssm restart `"$ServiceName`""
    Write-Host "  Edit:     nssm edit `"$ServiceName`""
    Write-Host "  Remove:   nssm remove `"$ServiceName`" confirm"
    Write-Host ""
    Write-Host "Windows Commands:" -ForegroundColor Yellow
    Write-Host "  Status:   Get-Service -Name `"$ServiceName`""
    Write-Host "  Start:    Start-Service -Name `"$ServiceName`""
    Write-Host "  Stop:     Stop-Service -Name `"$ServiceName`""
    Write-Host "  GUI:      services.msc"
    Write-Host ""
    Write-Host "Log Files:" -ForegroundColor Yellow
    Write-Host "  Service:  C:\Logs\$ServiceName-*.log"
    Write-Host "  Script:   ContinuousRunnerLogs folder"
    Write-Host ""
    
    Write-Host "✅ NSSM Service setup completed!" -ForegroundColor Green
    
}
catch {
    Write-Error "Setup failed: $($_.Exception.Message)"
    Write-Host ""
    Write-Host "Troubleshooting steps:" -ForegroundColor Yellow
    Write-Host "1. Verify you're running as Administrator"
    Write-Host "2. Check that NSSM is installed and accessible"
    Write-Host "3. Ensure all file paths are correct and accessible"
    Write-Host "4. Try: nssm --version (to test NSSM installation)"
    exit 1
}

<#
.NOTES
Quick Usage Examples:

# Basic setup
.\Create-NSSM-Service.ps1 -ScriptPath "C:\Scripts\MyScript.ps1" -StartService

# With config file
$params = @{ ConfigPath = "C:\Scripts\config.json" }
.\Create-NSSM-Service.ps1 -ScriptPath "C:\Scripts\MyScript.ps1" -ScriptParameters $params -IntervalHours 4

# Scheduled execution
.\Create-NSSM-Service.ps1 -ScriptPath "C:\Scripts\MyScript.ps1" -ScheduledDays @("Monday","Friday") -ScheduledTimes @("09:00","17:00")

# Custom service name and NSSM path
.\Create-NSSM-Service.ps1 -ScriptPath "C:\Scripts\MyScript.ps1" -ServiceName "MyCustomService" -NSSMPath "C:\Tools\nssm\nssm.exe" -StartService
#>
