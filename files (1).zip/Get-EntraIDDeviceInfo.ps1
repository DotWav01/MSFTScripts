#Requires -Modules Microsoft.Graph.DeviceManagement, Microsoft.Graph.Authentication, Microsoft.Graph.Users

<#
.SYNOPSIS
    Retrieves Entra ID device information with multiple query modes and export options.

.DESCRIPTION
    This script provides comprehensive device information retrieval from Entra ID with three distinct modes:
    1. Device Name Mode: Query devices by specific device names from CSV
    2. User Mode: Query devices by UserPrincipalNames with optional device type filtering
    3. All Devices Mode: Retrieve all tenant devices with optional filtering
    
    Results can be exported to multiple formats including CSV, JSON, XML, and HTML.

.PARAMETER Mode
    Specifies the operation mode. Valid values: 'DeviceName', 'User', 'AllDevices'

.PARAMETER InputFile
    Path to the CSV input file. Required for DeviceName and User modes.

.PARAMETER DeviceTypeFilter
    Filters devices by operating system. Valid values: 'Windows', 'iOS', 'Android', 'macOS', 'All'

.PARAMETER ExportFormat
    Output file format. Valid values: 'CSV', 'JSON', 'XML', 'HTML', 'All'

.PARAMETER OutputPath
    Directory path for output files. Defaults to current directory.

.PARAMETER OutputFileName
    Base name for output files. Defaults to 'EntraID-Devices-{timestamp}'

.PARAMETER IncludeCompliance
    Include device compliance information in the results.

.PARAMETER IncludeLastActivity
    Include last sign-in and activity information.

.PARAMETER WhatIf
    Shows what would happen if the script runs without actually executing the operations.

.EXAMPLE
    .\Get-EntraIDDeviceInfo.ps1 -Mode DeviceName -InputFile "C:\DeviceNames.csv" -ExportFormat CSV
    
    Retrieves device information for devices listed in DeviceNames.csv and exports to CSV format.

.EXAMPLE
    .\Get-EntraIDDeviceInfo.ps1 -Mode User -InputFile "C:\Users.csv" -DeviceTypeFilter Windows -ExportFormat JSON
    
    Retrieves Windows devices for users listed in Users.csv and exports to JSON format.

.EXAMPLE
    .\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter iOS -ExportFormat All -IncludeCompliance
    
    Retrieves all iOS devices in the tenant with compliance information and exports to all supported formats.

.NOTES
    File Name      : Get-EntraIDDeviceInfo.ps1
    Author         : IT Infrastructure Team
    Prerequisite   : Microsoft Graph PowerShell SDK
    
    Required Permissions:
    - DeviceManagementManagedDevices.Read.All
    - Device.Read.All
    - User.Read.All
    
    Input CSV Format for DeviceName mode:
    DeviceName
    LAPTOP-ABC123
    DESKTOP-XYZ789
    
    Input CSV Format for User mode:
    UserPrincipalName
    john.doe@company.com
    jane.smith@company.com

.LINK
    https://docs.microsoft.com/en-us/graph/api/resources/device
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('DeviceName', 'User', 'AllDevices')]
    [string]$Mode,
    
    [Parameter(Mandatory = $false)]
    [ValidateScript({
        if ($_ -and -not (Test-Path $_ -PathType Leaf)) {
            throw "Input file '$_' does not exist."
        }
        return $true
    })]
    [string]$InputFile,
    
    [Parameter(Mandatory = $false)]
    [ValidateSet('Windows', 'iOS', 'Android', 'macOS', 'All')]
    [string]$DeviceTypeFilter = 'All',
    
    [Parameter(Mandatory = $false)]
    [ValidateSet('CSV', 'JSON', 'XML', 'HTML', 'All')]
    [string]$ExportFormat = 'CSV',
    
    [Parameter(Mandatory = $false)]
    [ValidateScript({
        if ($_ -and -not (Test-Path $_ -PathType Container)) {
            throw "Output path '$_' does not exist."
        }
        return $true
    })]
    [string]$OutputPath = (Get-Location).Path,
    
    [Parameter(Mandatory = $false)]
    [string]$OutputFileName = "EntraID-Devices-$(Get-Date -Format 'yyyyMMdd-HHmmss')",
    
    [Parameter(Mandatory = $false)]
    [switch]$IncludeCompliance,
    
    [Parameter(Mandatory = $false)]
    [switch]$IncludeLastActivity,
    
    [Parameter(Mandatory = $false)]
    [switch]$Detailed
)

# Global Variables
$script:Results = @()
$script:TotalProcessed = 0
$script:ErrorCount = 0
$script:StartTime = Get-Date

#region Helper Functions

function Write-LogMessage {
    <#
    .SYNOPSIS
        Writes formatted log messages with timestamps.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet('Info', 'Warning', 'Error', 'Success')]
        [string]$Level = 'Info'
    )
    
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $colorMap = @{
        'Info'    = 'White'
        'Warning' = 'Yellow'
        'Error'   = 'Red'
        'Success' = 'Green'
    }
    
    Write-Host "[$timestamp] [$Level] $Message" -ForegroundColor $colorMap[$Level]
}

function Test-GraphConnection {
    <#
    .SYNOPSIS
        Tests Microsoft Graph connection and required permissions.
    #>
    try {
        $context = Get-MgContext
        if (-not $context) {
            Write-LogMessage "Not connected to Microsoft Graph. Attempting to connect..." -Level Warning
            Connect-MgGraph -Scopes "DeviceManagementManagedDevices.Read.All", "Device.Read.All", "User.Read.All" -NoWelcome
            $context = Get-MgContext
        }
        
        Write-LogMessage "Connected to Microsoft Graph as: $($context.Account)" -Level Success
        return $true
    }
    catch {
        Write-LogMessage "Failed to connect to Microsoft Graph: $($_.Exception.Message)" -Level Error
        return $false
    }
}

function Get-DeviceTypeFilter {
    <#
    .SYNOPSIS
        Creates filter string for device operating system.
    #>
    param([string]$DeviceType)
    
    switch ($DeviceType) {
        'Windows' { return "operatingSystem eq 'Windows'" }
        'iOS' { return "operatingSystem eq 'iOS'" }
        'Android' { return "operatingSystem eq 'Android'" }
        'macOS' { return "operatingSystem eq 'macOS'" }
        default { return $null }
    }
}

function Get-DeviceOwnerInfo {
    <#
    .SYNOPSIS
        Retrieves device owner information from registered users.
    #>
    param([string]$DeviceId)
    
    try {
        $registeredUsers = Get-MgDeviceRegisteredUser -DeviceId $DeviceId -ErrorAction SilentlyContinue
        if ($registeredUsers) {
            $userInfo = Get-MgUser -UserId $registeredUsers[0].Id -Select "UserPrincipalName,DisplayName,Department,JobTitle" -ErrorAction SilentlyContinue
            return @{
                UserPrincipalName = $userInfo.UserPrincipalName
                DisplayName = $userInfo.DisplayName
                Department = $userInfo.Department
                JobTitle = $userInfo.JobTitle
            }
        }
        
        # Fallback to registered owners if no registered users found
        $registeredOwners = Get-MgDeviceRegisteredOwner -DeviceId $DeviceId -ErrorAction SilentlyContinue
        if ($registeredOwners) {
            $userInfo = Get-MgUser -UserId $registeredOwners[0].Id -Select "UserPrincipalName,DisplayName,Department,JobTitle" -ErrorAction SilentlyContinue
            return @{
                UserPrincipalName = $userInfo.UserPrincipalName
                DisplayName = $userInfo.DisplayName
                Department = $userInfo.Department
                JobTitle = $userInfo.JobTitle
            }
        }
        
        return @{
            UserPrincipalName = "Not Found"
            DisplayName = "Not Found"
            Department = "Not Found"
            JobTitle = "Not Found"
        }
    }
    catch {
        Write-LogMessage "Error retrieving owner info for device $DeviceId`: $($_.Exception.Message)" -Level Warning
        return @{
            UserPrincipalName = "Error"
            DisplayName = "Error"
            Department = "Error"
            JobTitle = "Error"
        }
    }
}

function Get-DeviceComplianceInfo {
    <#
    .SYNOPSIS
        Retrieves device compliance information.
    #>
    param([string]$DeviceId)
    
    try {
        $managedDevice = Get-MgDeviceManagementManagedDevice -Filter "azureADDeviceId eq '$DeviceId'" -ErrorAction SilentlyContinue
        if ($managedDevice) {
            return @{
                ComplianceState = $managedDevice.ComplianceState
                LastComplianceReportedDateTime = $managedDevice.ComplianceGracePeriodExpirationDateTime
                IsEncrypted = $managedDevice.IsEncrypted
                IsSupervised = $managedDevice.IsSupervised
            }
        }
        
        return @{
            ComplianceState = "Not Managed"
            LastComplianceReportedDateTime = $null
            IsEncrypted = $null
            IsSupervised = $null
        }
    }
    catch {
        Write-LogMessage "Error retrieving compliance info for device $DeviceId`: $($_.Exception.Message)" -Level Warning
        return @{
            ComplianceState = "Error"
            LastComplianceReportedDateTime = $null
            IsEncrypted = $null
            IsSupervised = $null
        }
    }
}

function New-DeviceInfoObject {
    <#
    .SYNOPSIS
        Creates a standardized device information object.
    #>
    param(
        [object]$Device,
        [hashtable]$OwnerInfo,
        [hashtable]$ComplianceInfo
    )
    
    $deviceObj = [PSCustomObject]@{
        DeviceName = $Device.DisplayName
        DeviceId = $Device.Id
        OperatingSystem = $Device.OperatingSystem
        OperatingSystemVersion = $Device.OperatingSystemVersion
        IsCompliant = $Device.IsCompliant
        IsManaged = $Device.IsManaged
        TrustType = $Device.TrustType
        DeviceCategory = $Device.DeviceCategory
        ApproximateLastSignInDateTime = $Device.ApproximateLastSignInDateTime
        CreatedDateTime = $Device.CreatedDateTime
        OnPremisesSyncEnabled = $Device.OnPremisesSyncEnabled
        UserPrincipalName = $OwnerInfo.UserPrincipalName
        UserDisplayName = $OwnerInfo.DisplayName
        UserDepartment = $OwnerInfo.Department
        UserJobTitle = $OwnerInfo.JobTitle
    }
    
    if ($IncludeCompliance -and $ComplianceInfo) {
        $deviceObj | Add-Member -NotePropertyName 'ComplianceState' -NotePropertyValue $ComplianceInfo.ComplianceState
        $deviceObj | Add-Member -NotePropertyName 'LastComplianceReported' -NotePropertyValue $ComplianceInfo.LastComplianceReportedDateTime
        $deviceObj | Add-Member -NotePropertyName 'IsEncrypted' -NotePropertyValue $ComplianceInfo.IsEncrypted
        $deviceObj | Add-Member -NotePropertyName 'IsSupervised' -NotePropertyValue $ComplianceInfo.IsSupervised
    }
    
    if ($Detailed) {
        $deviceObj | Add-Member -NotePropertyName 'DeviceOwnership' -NotePropertyValue $Device.DeviceOwnership
        $deviceObj | Add-Member -NotePropertyName 'EnrollmentType' -NotePropertyValue $Device.EnrollmentType
        $deviceObj | Add-Member -NotePropertyName 'ManagementType' -NotePropertyValue $Device.ManagementType
    }
    
    return $deviceObj
}

#endregion Helper Functions

#region Main Processing Functions

function Invoke-DeviceNameMode {
    <#
    .SYNOPSIS
        Processes devices by device names from CSV input.
    #>
    param([string]$FilePath)
    
    Write-LogMessage "Starting Device Name mode processing..." -Level Info
    
    try {
        $deviceNames = Import-Csv -Path $FilePath
        if (-not $deviceNames -or -not $deviceNames[0].PSObject.Properties['DeviceName']) {
            throw "CSV file must contain a 'DeviceName' column."
        }
        
        $totalDevices = $deviceNames.Count
        Write-LogMessage "Found $totalDevices device names to process" -Level Info
        
        $counter = 0
        foreach ($row in $deviceNames) {
            $counter++
            $deviceName = $row.DeviceName.Trim()
            
            Write-Progress -Activity "Processing Devices" -Status "Processing $deviceName ($counter of $totalDevices)" -PercentComplete (($counter / $totalDevices) * 100)
            
            if ([string]::IsNullOrWhiteSpace($deviceName)) {
                Write-LogMessage "Skipping empty device name at row $counter" -Level Warning
                continue
            }
            
            try {
                $devices = Get-MgDevice -Filter "displayName eq '$deviceName'" -Select "id,displayName,operatingSystem,operatingSystemVersion,isCompliant,isManaged,trustType,deviceCategory,approximateLastSignInDateTime,createdDateTime,onPremisesSyncEnabled,deviceOwnership,enrollmentType,managementType"
                
                if ($devices) {
                    foreach ($device in $devices) {
                        if ($PSCmdlet.ShouldProcess($device.DisplayName, "Retrieve device information")) {
                            $ownerInfo = Get-DeviceOwnerInfo -DeviceId $device.Id
                            $complianceInfo = $null
                            
                            if ($IncludeCompliance) {
                                $complianceInfo = Get-DeviceComplianceInfo -DeviceId $device.Id
                            }
                            
                            $deviceObj = New-DeviceInfoObject -Device $device -OwnerInfo $ownerInfo -ComplianceInfo $complianceInfo
                            $script:Results += $deviceObj
                            $script:TotalProcessed++
                        }
                    }
                    
                    Write-LogMessage "Found $($devices.Count) device(s) for name: $deviceName" -Level Success
                }
                else {
                    Write-LogMessage "No device found for name: $deviceName" -Level Warning
                }
            }
            catch {
                Write-LogMessage "Error processing device '$deviceName': $($_.Exception.Message)" -Level Error
                $script:ErrorCount++
            }
        }
        
        Write-Progress -Activity "Processing Devices" -Completed
    }
    catch {
        Write-LogMessage "Error in Device Name mode: $($_.Exception.Message)" -Level Error
        throw
    }
}

function Invoke-UserMode {
    <#
    .SYNOPSIS
        Processes devices by user principal names from CSV input.
    #>
    param([string]$FilePath)
    
    Write-LogMessage "Starting User mode processing..." -Level Info
    
    try {
        $users = Import-Csv -Path $FilePath
        if (-not $users -or -not $users[0].PSObject.Properties['UserPrincipalName']) {
            throw "CSV file must contain a 'UserPrincipalName' column."
        }
        
        $totalUsers = $users.Count
        Write-LogMessage "Found $totalUsers users to process" -Level Info
        
        $counter = 0
        foreach ($row in $users) {
            $counter++
            $userPrincipalName = $row.UserPrincipalName.Trim()
            
            Write-Progress -Activity "Processing User Devices" -Status "Processing $userPrincipalName ($counter of $totalUsers)" -PercentComplete (($counter / $totalUsers) * 100)
            
            if ([string]::IsNullOrWhiteSpace($userPrincipalName)) {
                Write-LogMessage "Skipping empty user principal name at row $counter" -Level Warning
                continue
            }
            
            try {
                # Get user first
                $user = Get-MgUser -Filter "userPrincipalName eq '$userPrincipalName'" -Select "id,userPrincipalName,displayName,department,jobTitle" -ErrorAction SilentlyContinue
                
                if (-not $user) {
                    Write-LogMessage "User not found: $userPrincipalName" -Level Warning
                    continue
                }
                
                # Get user's registered devices
                $userDevices = Get-MgUserRegisteredDevice -UserId $user.Id
                
                if ($userDevices) {
                    foreach ($deviceRef in $userDevices) {
                        try {
                            $device = Get-MgDevice -DeviceId $deviceRef.Id -Select "id,displayName,operatingSystem,operatingSystemVersion,isCompliant,isManaged,trustType,deviceCategory,approximateLastSignInDateTime,createdDateTime,onPremisesSyncEnabled,deviceOwnership,enrollmentType,managementType"
                            
                            # Apply device type filter if specified
                            if ($DeviceTypeFilter -ne 'All') {
                                $filterCondition = Get-DeviceTypeFilter -DeviceType $DeviceTypeFilter
                                if ($filterCondition -and $device.OperatingSystem -ne $DeviceTypeFilter) {
                                    continue
                                }
                            }
                            
                            if ($PSCmdlet.ShouldProcess($device.DisplayName, "Retrieve device information")) {
                                $ownerInfo = @{
                                    UserPrincipalName = $user.UserPrincipalName
                                    DisplayName = $user.DisplayName
                                    Department = $user.Department
                                    JobTitle = $user.JobTitle
                                }
                                
                                $complianceInfo = $null
                                if ($IncludeCompliance) {
                                    $complianceInfo = Get-DeviceComplianceInfo -DeviceId $device.Id
                                }
                                
                                $deviceObj = New-DeviceInfoObject -Device $device -OwnerInfo $ownerInfo -ComplianceInfo $complianceInfo
                                $script:Results += $deviceObj
                                $script:TotalProcessed++
                            }
                        }
                        catch {
                            Write-LogMessage "Error processing device for user '$userPrincipalName': $($_.Exception.Message)" -Level Warning
                        }
                    }
                    
                    Write-LogMessage "Processed $($userDevices.Count) device(s) for user: $userPrincipalName" -Level Success
                }
                else {
                    Write-LogMessage "No devices found for user: $userPrincipalName" -Level Info
                }
            }
            catch {
                Write-LogMessage "Error processing user '$userPrincipalName': $($_.Exception.Message)" -Level Error
                $script:ErrorCount++
            }
        }
        
        Write-Progress -Activity "Processing User Devices" -Completed
    }
    catch {
        Write-LogMessage "Error in User mode: $($_.Exception.Message)" -Level Error
        throw
    }
}

function Invoke-AllDevicesMode {
    <#
    .SYNOPSIS
        Processes all devices in the tenant with optional filtering.
    #>
    
    Write-LogMessage "Starting All Devices mode processing..." -Level Info
    
    try {
        $filter = $null
        if ($DeviceTypeFilter -ne 'All') {
            $filter = Get-DeviceTypeFilter -DeviceType $DeviceTypeFilter
        }
        
        Write-LogMessage "Retrieving all devices from tenant..." -Level Info
        
        $allDevices = if ($filter) {
            Get-MgDevice -Filter $filter -All -Select "id,displayName,operatingSystem,operatingSystemVersion,isCompliant,isManaged,trustType,deviceCategory,approximateLastSignInDateTime,createdDateTime,onPremisesSyncEnabled,deviceOwnership,enrollmentType,managementType"
        } else {
            Get-MgDevice -All -Select "id,displayName,operatingSystem,operatingSystemVersion,isCompliant,isManaged,trustType,deviceCategory,approximateLastSignInDateTime,createdDateTime,onPremisesSyncEnabled,deviceOwnership,enrollmentType,managementType"
        }
        
        $totalDevices = $allDevices.Count
        Write-LogMessage "Found $totalDevices devices to process" -Level Info
        
        $counter = 0
        foreach ($device in $allDevices) {
            $counter++
            
            Write-Progress -Activity "Processing All Devices" -Status "Processing $($device.DisplayName) ($counter of $totalDevices)" -PercentComplete (($counter / $totalDevices) * 100)
            
            try {
                if ($PSCmdlet.ShouldProcess($device.DisplayName, "Retrieve device information")) {
                    $ownerInfo = Get-DeviceOwnerInfo -DeviceId $device.Id
                    $complianceInfo = $null
                    
                    if ($IncludeCompliance) {
                        $complianceInfo = Get-DeviceComplianceInfo -DeviceId $device.Id
                    }
                    
                    $deviceObj = New-DeviceInfoObject -Device $device -OwnerInfo $ownerInfo -ComplianceInfo $complianceInfo
                    $script:Results += $deviceObj
                    $script:TotalProcessed++
                }
            }
            catch {
                Write-LogMessage "Error processing device '$($device.DisplayName)': $($_.Exception.Message)" -Level Error
                $script:ErrorCount++
            }
        }
        
        Write-Progress -Activity "Processing All Devices" -Completed
    }
    catch {
        Write-LogMessage "Error in All Devices mode: $($_.Exception.Message)" -Level Error
        throw
    }
}

#endregion Main Processing Functions

#region Export Functions

function Export-ToCSV {
    <#
    .SYNOPSIS
        Exports results to CSV format.
    #>
    param([string]$FilePath)
    
    try {
        $script:Results | Export-Csv -Path $FilePath -NoTypeInformation -Encoding UTF8
        Write-LogMessage "Results exported to CSV: $FilePath" -Level Success
        return $true
    }
    catch {
        Write-LogMessage "Error exporting to CSV: $($_.Exception.Message)" -Level Error
        return $false
    }
}

function Export-ToJSON {
    <#
    .SYNOPSIS
        Exports results to JSON format.
    #>
    param([string]$FilePath)
    
    try {
        $jsonOutput = @{
            ExportDateTime = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            TotalDevices = $script:Results.Count
            ProcessingMode = $Mode
            DeviceTypeFilter = $DeviceTypeFilter
            Devices = $script:Results
        }
        
        $jsonOutput | ConvertTo-Json -Depth 10 | Out-File -FilePath $FilePath -Encoding UTF8
        Write-LogMessage "Results exported to JSON: $FilePath" -Level Success
        return $true
    }
    catch {
        Write-LogMessage "Error exporting to JSON: $($_.Exception.Message)" -Level Error
        return $false
    }
}

function Export-ToXML {
    <#
    .SYNOPSIS
        Exports results to XML format.
    #>
    param([string]$FilePath)
    
    try {
        $xmlDoc = New-Object System.Xml.XmlDocument
        $root = $xmlDoc.CreateElement("EntraIDDevices")
        $xmlDoc.AppendChild($root) | Out-Null
        
        # Add metadata
        $metadata = $xmlDoc.CreateElement("Metadata")
        $metadata.SetAttribute("ExportDateTime", (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
        $metadata.SetAttribute("TotalDevices", $script:Results.Count)
        $metadata.SetAttribute("ProcessingMode", $Mode)
        $metadata.SetAttribute("DeviceTypeFilter", $DeviceTypeFilter)
        $root.AppendChild($metadata) | Out-Null
        
        # Add devices
        $devicesElement = $xmlDoc.CreateElement("Devices")
        $root.AppendChild($devicesElement) | Out-Null
        
        foreach ($device in $script:Results) {
            $deviceElement = $xmlDoc.CreateElement("Device")
            
            foreach ($property in $device.PSObject.Properties) {
                $propertyElement = $xmlDoc.CreateElement($property.Name)
                $propertyElement.InnerText = if ($property.Value) { $property.Value.ToString() } else { "" }
                $deviceElement.AppendChild($propertyElement) | Out-Null
            }
            
            $devicesElement.AppendChild($deviceElement) | Out-Null
        }
        
        $xmlDoc.Save($FilePath)
        Write-LogMessage "Results exported to XML: $FilePath" -Level Success
        return $true
    }
    catch {
        Write-LogMessage "Error exporting to XML: $($_.Exception.Message)" -Level Error
        return $false
    }
}

function Export-ToHTML {
    <#
    .SYNOPSIS
        Exports results to HTML format with styling.
    #>
    param([string]$FilePath)
    
    try {
        $htmlContent = @"
<!DOCTYPE html>
<html>
<head>
    <title>Entra ID Device Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #0078d4; color: white; padding: 15px; margin-bottom: 20px; }
        .summary { background-color: #f3f2f1; padding: 10px; margin-bottom: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #0078d4; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .compliant { color: green; font-weight: bold; }
        .non-compliant { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Entra ID Device Report</h1>
        <p>Generated on: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
    </div>
    
    <div class="summary">
        <h2>Summary</h2>
        <p><strong>Processing Mode:</strong> $Mode</p>
        <p><strong>Device Type Filter:</strong> $DeviceTypeFilter</p>
        <p><strong>Total Devices Found:</strong> $($script:Results.Count)</p>
        <p><strong>Processing Duration:</strong> $((Get-Date) - $script:StartTime)</p>
    </div>
    
    <h2>Device Details</h2>
    <table>
        <thead>
            <tr>
"@

        # Add headers dynamically based on result properties
        if ($script:Results.Count -gt 0) {
            foreach ($property in $script:Results[0].PSObject.Properties.Name) {
                $htmlContent += "<th>$property</th>"
            }
        }
        
        $htmlContent += @"
            </tr>
        </thead>
        <tbody>
"@

        # Add data rows
        foreach ($device in $script:Results) {
            $htmlContent += "<tr>"
            foreach ($property in $device.PSObject.Properties) {
                $value = if ($property.Value) { $property.Value.ToString() } else { "" }
                $class = ""
                
                # Add special formatting for compliance
                if ($property.Name -eq "IsCompliant") {
                    $class = if ($value -eq "True") { "compliant" } else { "non-compliant" }
                }
                
                $htmlContent += "<td class='$class'>$value</td>"
            }
            $htmlContent += "</tr>"
        }
        
        $htmlContent += @"
        </tbody>
    </table>
</body>
</html>
"@

        $htmlContent | Out-File -FilePath $FilePath -Encoding UTF8
        Write-LogMessage "Results exported to HTML: $FilePath" -Level Success
        return $true
    }
    catch {
        Write-LogMessage "Error exporting to HTML: $($_.Exception.Message)" -Level Error
        return $false
    }
}

function Invoke-ExportResults {
    <#
    .SYNOPSIS
        Orchestrates the export process based on specified format.
    #>
    
    if ($script:Results.Count -eq 0) {
        Write-LogMessage "No results to export." -Level Warning
        return
    }
    
    Write-LogMessage "Starting export process..." -Level Info
    
    $exportFormats = if ($ExportFormat -eq 'All') {
        @('CSV', 'JSON', 'XML', 'HTML')
    } else {
        @($ExportFormat)
    }
    
    $successCount = 0
    
    foreach ($format in $exportFormats) {
        $fileName = "$OutputFileName.$($format.ToLower())"
        $fullPath = Join-Path -Path $OutputPath -ChildPath $fileName
        
        $success = switch ($format) {
            'CSV'  { Export-ToCSV -FilePath $fullPath }
            'JSON' { Export-ToJSON -FilePath $fullPath }
            'XML'  { Export-ToXML -FilePath $fullPath }
            'HTML' { Export-ToHTML -FilePath $fullPath }
        }
        
        if ($success) { $successCount++ }
    }
    
    Write-LogMessage "Export completed. $successCount of $($exportFormats.Count) formats exported successfully." -Level Info
}

#endregion Export Functions

#region Main Execution

function Show-Summary {
    <#
    .SYNOPSIS
        Displays execution summary.
    #>
    
    $duration = (Get-Date) - $script:StartTime
    
    Write-LogMessage "=== Execution Summary ===" -Level Info
    Write-LogMessage "Mode: $Mode" -Level Info
    Write-LogMessage "Device Type Filter: $DeviceTypeFilter" -Level Info
    Write-LogMessage "Total Devices Processed: $script:TotalProcessed" -Level Info
    Write-LogMessage "Errors Encountered: $script:ErrorCount" -Level Info
    Write-LogMessage "Processing Duration: $($duration.ToString('hh\:mm\:ss'))" -Level Info
    Write-LogMessage "Results Count: $($script:Results.Count)" -Level Info
    Write-LogMessage "=========================" -Level Info
}

# Main execution block
try {
    Write-LogMessage "Starting Entra ID Device Information Script..." -Level Info
    Write-LogMessage "Mode: $Mode | Device Filter: $DeviceTypeFilter | Export Format: $ExportFormat" -Level Info
    
    # Test Graph connection
    if (-not (Test-GraphConnection)) {
        throw "Failed to establish Microsoft Graph connection."
    }
    
    # Validate input file for modes that require it
    if ($Mode -in @('DeviceName', 'User') -and -not $InputFile) {
        throw "InputFile parameter is required for $Mode mode."
    }
    
    # Execute based on mode
    switch ($Mode) {
        'DeviceName' {
            Invoke-DeviceNameMode -FilePath $InputFile
        }
        'User' {
            Invoke-UserMode -FilePath $InputFile
        }
        'AllDevices' {
            Invoke-AllDevicesMode
        }
    }
    
    # Export results
    Invoke-ExportResults
    
    # Show summary
    Show-Summary
    
    Write-LogMessage "Script execution completed successfully." -Level Success
}
catch {
    Write-LogMessage "Script execution failed: $($_.Exception.Message)" -Level Error
    Show-Summary
    exit 1
}
finally {
    # Clean up if needed
    Write-Progress -Activity "Processing" -Completed
}

#endregion Main Execution
