#Requires -Version 5.1

<#
.SYNOPSIS
    Installs TSScan Server and deploys the site license file.

.DESCRIPTION
    Launched via ServiceUI_x64.exe → Launch-TSScan.bat to bridge the SYSTEM
    context to the active user session, allowing the TSScan Server interactive
    installer wizard to be displayed to the user. Uses ServiceUI internally to
    send toast notifications to the user at key installation milestones.
    After the wizard completes, the site license file is copied to the
    installation directory.

.NOTES
    Author  : IT Infrastructure
    Version : 1.1.0
    Date    : 2026-03-12

    Deployment:
        Intune Win32 - System context
        Install  : ServiceUI_x64.exe -Process:explorer.exe ".\Launch-TSScan.bat"
        Uninstall: powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& '${env:ProgramFiles(x86)}\TerminalWorks\TSScan Server\unins000.exe' /SILENT /NORESTART"
        Detection: File exists - C:\Program Files (x86)\TerminalWorks\TSScan Server\unins000.exe

    Package structure:
        TSScanServer\
        ├── TSScan_server.exe
        ├── TSScan-site.twlic
        ├── ServiceUI_x64.exe
        ├── Launch-TSScan.bat
        ├── Show-Toast.ps1
        └── Install-TSScanServer.ps1

.EXAMPLE
    # Test manually as SYSTEM via PsExec:
    psexec.exe -s powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Install-TSScanServer.ps1"
#>

$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
$LogPath = 'C:\softdist\Logs'
$LogFile = Join-Path $LogPath 'TSScanServer_Install.log'

if (-not (Test-Path $LogPath)) {
    New-Item -Path $LogPath -ItemType Directory -Force | Out-Null
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR')]
        [string]$Level = 'INFO'
    )
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$timestamp] [$Level] $Message"
    Add-Content -Path $LogFile -Value $entry
    Write-Output $entry
}

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
$ScriptDir     = Split-Path -Parent $MyInvocation.MyCommand.Definition
$InstallerPath = Join-Path $ScriptDir 'TSScan_server.exe'
$LicenseSrc    = Join-Path $ScriptDir 'TSScan-site.twlic'
$ServiceUI     = Join-Path $ScriptDir 'ServiceUI_x64.exe'
$ToastScript   = Join-Path $ScriptDir 'Show-Toast.ps1'

Write-Log "=== TSScan Server Install Started ==="
Write-Log "Script directory : $ScriptDir"
Write-Log "Running as       : $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"

# ---------------------------------------------------------------------------
# Toast helper - fires Show-Toast.ps1 in user session via ServiceUI
# ---------------------------------------------------------------------------
function Send-ToastToUser {
    param(
        [string]$Title,
        [string]$Message
    )
    try {
        $argList = "-Process:explorer.exe powershell.exe -NoProfile -ExecutionPolicy Bypass " +
                   "-WindowStyle Hidden -File `"$ToastScript`" " +
                   "-Title `"$Title`" -Message `"$Message`""

        Start-Process -FilePath $ServiceUI `
            -ArgumentList $argList `
            -Wait `
            -WindowStyle Hidden

        Write-Log "Toast sent: [$Title] $Message"
    } catch {
        Write-Log "Failed to send toast (non-fatal): $_" 'WARN'
    }
}

# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------
foreach ($file in @($InstallerPath, $LicenseSrc, $ServiceUI, $ToastScript)) {
    if (-not (Test-Path $file)) {
        Write-Log "Required file not found: $file" 'ERROR'
        exit 1
    }
}
Write-Log "Pre-flight checks passed. All required files verified."

# ---------------------------------------------------------------------------
# Toast 1 - Notify user wizard is about to appear
# ---------------------------------------------------------------------------
Send-ToastToUser `
    -Title 'TSScan Server Installation' `
    -Message 'The TSScan Server setup wizard is starting. Please follow the steps to complete installation.'

# ---------------------------------------------------------------------------
# Launch interactive installer
# ---------------------------------------------------------------------------
Write-Log "Launching TSScan Server interactive installer wizard..."
try {
    $process = Start-Process -FilePath $InstallerPath `
        -Wait `
        -PassThru

    Write-Log "Installer exited with code: $($process.ExitCode)"
} catch {
    Write-Log "Failed to launch installer: $_" 'ERROR'
    Send-ToastToUser `
        -Title 'TSScan Server Installation Failed' `
        -Message 'The installer could not be launched. Please contact IT support.'
    exit 1
}

# ---------------------------------------------------------------------------
# Verify installation directory
# ---------------------------------------------------------------------------
$installDirX86 = "${env:ProgramFiles(x86)}\TerminalWorks\TSScan Server"
$installDirX64 = "$env:ProgramFiles\TerminalWorks\TSScan Server"

if (Test-Path $installDirX86) {
    $installDir = $installDirX86
} elseif (Test-Path $installDirX64) {
    $installDir = $installDirX64
} else {
    Write-Log "Installation directory not found. Installer may have been cancelled or failed." 'ERROR'
    Send-ToastToUser `
        -Title 'TSScan Server Installation Incomplete' `
        -Message 'Setup did not complete. If you cancelled the wizard, please reinstall from the Company Portal.'
    exit 1
}

Write-Log "Installation directory found: $installDir"

# ---------------------------------------------------------------------------
# Copy license file
# ---------------------------------------------------------------------------
$licenseDst = Join-Path $installDir 'TSScan-site.twlic'
try {
    Copy-Item -Path $LicenseSrc -Destination $licenseDst -Force
    Write-Log "License file copied to: $licenseDst"
} catch {
    Write-Log "Failed to copy license file: $_" 'ERROR'
    Send-ToastToUser `
        -Title 'TSScan Server Installation Warning' `
        -Message 'Installation completed but the license file could not be copied. Please contact IT support.'
    exit 1
}

# ---------------------------------------------------------------------------
# Toast 2 - Success
# ---------------------------------------------------------------------------
Send-ToastToUser `
    -Title 'TSScan Server Installation Complete' `
    -Message 'TSScan Server has been successfully installed and is ready to use.'

Write-Log "=== TSScan Server Install Completed Successfully ==="
exit 0
