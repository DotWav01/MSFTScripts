# Entra ID Device Information Script

A comprehensive PowerShell script for retrieving device information from Entra ID (Azure Active Directory) with multiple query modes and export formats.

## Features

- **Multiple Query Modes**: Device Name, User-based, or All Devices
- **Device Type Filtering**: Filter by Windows, iOS, Android, macOS, or All
- **Multiple Export Formats**: CSV, JSON, XML, HTML, or All formats
- **Compliance Information**: Optional device compliance and management details
- **Owner Information**: Retrieve device owner/user details
- **Progress Tracking**: Real-time progress indicators for large operations
- **Error Handling**: Comprehensive error logging and recovery
- **WhatIf Support**: Preview operations without making changes

## Prerequisites

### Required PowerShell Modules
```powershell
Install-Module Microsoft.Graph.DeviceManagement -Force
Install-Module Microsoft.Graph.Authentication -Force
Install-Module Microsoft.Graph.Users -Force
```

### Required Permissions
The script requires the following Microsoft Graph permissions:
- `DeviceManagementManagedDevices.Read.All`
- `Device.Read.All`
- `User.Read.All`

### Authentication
The script will automatically prompt for authentication if not already connected to Microsoft Graph.

## Usage

### Mode 1: Device Name Query

Query specific devices by their display names from a CSV file.

```powershell
# Basic device name query
.\Get-EntraIDDeviceInfo.ps1 -Mode DeviceName -InputFile "DeviceNames.csv"

# With compliance information and JSON export
.\Get-EntraIDDeviceInfo.ps1 -Mode DeviceName -InputFile "DeviceNames.csv" -IncludeCompliance -ExportFormat JSON

# Export to all formats
.\Get-EntraIDDeviceInfo.ps1 -Mode DeviceName -InputFile "DeviceNames.csv" -ExportFormat All
```

**Required CSV Format:**
```csv
DeviceName
LAPTOP-ABC123
DESKTOP-XYZ789
TABLET-DEF456
```

### Mode 2: User-based Query

Query devices registered to specific users with optional device type filtering.

```powershell
# Get all devices for users
.\Get-EntraIDDeviceInfo.ps1 -Mode User -InputFile "Users.csv"

# Get only Windows devices for users
.\Get-EntraIDDeviceInfo.ps1 -Mode User -InputFile "Users.csv" -DeviceTypeFilter Windows

# Get iOS devices with compliance info
.\Get-EntraIDDeviceInfo.ps1 -Mode User -InputFile "Users.csv" -DeviceTypeFilter iOS -IncludeCompliance
```

**Required CSV Format:**
```csv
UserPrincipalName
john.doe@company.com
jane.smith@company.com
mike.johnson@company.com
```

### Mode 3: All Devices Query

Query all devices in the tenant with optional filtering.

```powershell
# Get all devices
.\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices

# Get only Android devices
.\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter Android

# Get all Windows devices with full details
.\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter Windows -IncludeCompliance -Detailed
```

## Parameters

| Parameter | Type | Description | Default |
|-----------|------|-------------|---------|
| `Mode` | String | Query mode: DeviceName, User, AllDevices | Required |
| `InputFile` | String | Path to CSV input file | Required for DeviceName/User modes |
| `DeviceTypeFilter` | String | Filter by OS: Windows, iOS, Android, macOS, All | All |
| `ExportFormat` | String | Output format: CSV, JSON, XML, HTML, All | CSV |
| `OutputPath` | String | Output directory path | Current directory |
| `OutputFileName` | String | Base output filename | EntraID-Devices-{timestamp} |
| `IncludeCompliance` | Switch | Include device compliance information | False |
| `IncludeLastActivity` | Switch | Include last activity information | False |
| `Detailed` | Switch | Include additional device properties | False |
| `WhatIf` | Switch | Preview operations without execution | False |

## Output Formats

### CSV Output
Standard comma-separated values file with all device information in tabular format.

### JSON Output
Structured JSON with metadata and device array:
```json
{
  "ExportDateTime": "2024-01-21 14:30:00",
  "TotalDevices": 150,
  "ProcessingMode": "AllDevices",
  "DeviceTypeFilter": "Windows",
  "Devices": [...]
}
```

### XML Output
Hierarchical XML structure with metadata and device elements.

### HTML Output
Styled HTML report with:
- Executive summary
- Device count statistics
- Searchable/sortable table
- Compliance status highlighting

## Output Properties

### Standard Properties
- **DeviceName**: Display name of the device
- **DeviceId**: Unique Azure AD device identifier
- **OperatingSystem**: Device operating system
- **OperatingSystemVersion**: OS version information
- **IsCompliant**: Compliance status
- **IsManaged**: Management status
- **TrustType**: Device trust relationship
- **DeviceCategory**: Category classification
- **ApproximateLastSignInDateTime**: Last sign-in timestamp
- **CreatedDateTime**: Device registration date
- **OnPremisesSyncEnabled**: On-premises sync status
- **UserPrincipalName**: Device owner UPN
- **UserDisplayName**: Device owner display name
- **UserDepartment**: Owner's department
- **UserJobTitle**: Owner's job title

### Compliance Properties (with -IncludeCompliance)
- **ComplianceState**: Detailed compliance status
- **LastComplianceReported**: Last compliance check
- **IsEncrypted**: Device encryption status
- **IsSupervised**: Device supervision status

### Detailed Properties (with -Detailed)
- **DeviceOwnership**: Ownership type (Corporate/Personal)
- **EnrollmentType**: How device was enrolled
- **ManagementType**: Management authority

## Examples

### Enterprise Device Audit
```powershell
# Get all corporate Windows devices with compliance info
.\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter Windows -IncludeCompliance -ExportFormat HTML
```

### User Device Inventory
```powershell
# Get all devices for HR department users
.\Get-EntraIDDeviceInfo.ps1 -Mode User -InputFile "HR-Users.csv" -ExportFormat JSON -Detailed
```

### Specific Device Investigation
```powershell
# Investigate specific devices with full details
.\Get-EntraIDDeviceInfo.ps1 -Mode DeviceName -InputFile "SuspiciousDevices.csv" -IncludeCompliance -Detailed -ExportFormat All
```

### Preview Mode
```powershell
# Preview what devices would be processed
.\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -DeviceTypeFilter iOS -WhatIf
```

## Error Handling

The script includes comprehensive error handling:
- **Connection Issues**: Automatic retry and clear error messages
- **Permission Errors**: Detailed permission requirement guidance
- **Data Issues**: Individual device processing errors don't stop execution
- **File Issues**: Input/output file validation and error reporting

## Performance Considerations

- **Large Tenants**: Use device type filtering to reduce processing time
- **Rate Limiting**: Built-in throttling for Microsoft Graph API limits
- **Memory Usage**: Large result sets are processed efficiently
- **Progress Tracking**: Real-time progress for long-running operations

## Troubleshooting

### Common Issues

1. **Authentication Failures**
   - Ensure proper Graph permissions are granted
   - Check if MFA is required for the account
   - Try disconnecting and reconnecting: `Disconnect-MgGraph; Connect-MgGraph`

2. **No Devices Found**
   - Verify device names are exactly as they appear in Entra ID
   - Check if devices are registered vs joined
   - Confirm user has registered devices

3. **Permission Errors**
   - Ensure application has required Graph permissions
   - Check if consent is granted at tenant level
   - Verify role assignments in Azure AD

4. **Performance Issues**
   - Use device type filtering for large tenants
   - Process users in smaller batches
   - Consider running during off-peak hours

### Debug Mode
Add `-Verbose` to any command for detailed execution information:
```powershell
.\Get-EntraIDDeviceInfo.ps1 -Mode AllDevices -Verbose
```

## Security Considerations

- **Credential Storage**: Use Azure Key Vault for production environments
- **Audit Logging**: All operations are logged with timestamps
- **Least Privilege**: Request only necessary Graph permissions
- **Data Privacy**: Consider data retention policies for exported files

## Version History

- **v1.0**: Initial release with basic functionality
- **v1.1**: Added compliance information and detailed mode
- **v1.2**: Added HTML export and improved error handling
- **v1.3**: Added progress tracking and WhatIf support

## Support

For issues or feature requests, contact the IT Infrastructure team or submit through the standard IT request process.

## License

Internal use only. Refer to corporate PowerShell script usage policies.
